﻿namespace hr4eInterface
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ListBoxPathType = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.IntakeTabReloadPatientButton = new System.Windows.Forms.Button();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.ButtonIntakeTabWritePatientFile = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.TextBoxIntakeTabDOBDay = new System.Windows.Forms.TextBox();
            this.TextBoxIntakeTabDOBYear = new System.Windows.Forms.TextBox();
            this.TextBoxIntakeTabEstAgeYears = new System.Windows.Forms.TextBox();
            this.TextBoxIntakeTabStatedAgeYears = new System.Windows.Forms.TextBox();
            this.TextBoxIntakeTabDOBMonth = new System.Windows.Forms.TextBox();
            this.TextBoxIntakeTabStatedAgeMonths = new System.Windows.Forms.TextBox();
            this.LabelIntakeTabDOB = new System.Windows.Forms.Label();
            this.TextBoxIntakeTabEstAgeMonths = new System.Windows.Forms.TextBox();
            this.IntakeTabResetLanguageButton = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.ButtonSelectAgeType = new System.Windows.Forms.Button();
            this.TextBoxIntakeTabPatientLastNameIn = new System.Windows.Forms.TextBox();
            this.ComboBoxIntakeTabSchoolList = new System.Windows.Forms.ComboBox();
            this.comboBox28 = new System.Windows.Forms.ComboBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LabelIntakeTabStatedAge = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.ComboBoxIntakeTabStatusInSchool = new System.Windows.Forms.ComboBox();
            this.ComboBoxIntakeTabPresentVillage = new System.Windows.Forms.ComboBox();
            this.ComboBoxIntakeTabHomeVillage = new System.Windows.Forms.ComboBox();
            this.ComboBoxIntakeTabTribe = new System.Windows.Forms.ComboBox();
            this.TextBoxIntakeTabPatientFirstNameIn = new System.Windows.Forms.TextBox();
            this.ComboBoxIntakeTabLanguageList = new System.Windows.Forms.ComboBox();
            this.GenderComboBox = new System.Windows.Forms.ComboBox();
            this.label99 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.LabelIntakeTabSchoolStatus = new System.Windows.Forms.Label();
            this.LabelIntakeTabPresentVillage = new System.Windows.Forms.Label();
            this.LabelIntakeTabSchoolYear = new System.Windows.Forms.Label();
            this.LabelIntakeTabeHomeVillage = new System.Windows.Forms.Label();
            this.LabelIntakeTabSchoolName = new System.Windows.Forms.Label();
            this.LabelIntakeTabLastName = new System.Windows.Forms.Label();
            this.LabelIntakeTabTribe = new System.Windows.Forms.Label();
            this.LabelIntakeTabFirstName = new System.Windows.Forms.Label();
            this.ButtonIntakeTabAddLanguage = new System.Windows.Forms.Button();
            this.LabelIntakePatientGender = new System.Windows.Forms.Label();
            this.LabelIntakeTabLanguage = new System.Windows.Forms.Label();
            this.ButtonIntakeTabBeginNewForm = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.TriageTabChiefComplaintInput = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label128 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label116 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.TriageTabToggle = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.label137 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.comboBox29 = new System.Windows.Forms.ComboBox();
            this.comboBox27 = new System.Windows.Forms.ComboBox();
            this.comboBox26 = new System.Windows.Forms.ComboBox();
            this.comboBox25 = new System.Windows.Forms.ComboBox();
            this.comboBox24 = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.label125 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.label123 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.ButtonClinicSaveData = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.comboBox23 = new System.Windows.Forms.ComboBox();
            this.label120 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label118 = new System.Windows.Forms.Label();
            this.comboBox22 = new System.Windows.Forms.ComboBox();
            this.label117 = new System.Windows.Forms.Label();
            this.ClinicTabNotesEntry = new System.Windows.Forms.RichTextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label52 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.ClinicTabLoadPatient = new System.Windows.Forms.Button();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.label132 = new System.Windows.Forms.Label();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label129 = new System.Windows.Forms.Label();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label126 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.textBox108 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.label147 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.label144 = new System.Windows.Forms.Label();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.button24 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button29 = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.comboBoxScribeList = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox109 = new System.Windows.Forms.TextBox();
            this.textBox110 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.textBox112 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.textBox113 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.textBox114 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox115 = new System.Windows.Forms.TextBox();
            this.textBox116 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.SuspendLayout();
            // 
            // ListBoxPathType
            // 
            this.ListBoxPathType.FormattingEnabled = true;
            this.ListBoxPathType.Location = new System.Drawing.Point(430, 19);
            this.ListBoxPathType.Name = "ListBoxPathType";
            this.ListBoxPathType.Size = new System.Drawing.Size(120, 69);
            this.ListBoxPathType.TabIndex = 6;
            this.ListBoxPathType.SelectedIndexChanged += new System.EventHandler(this.ListBoxPathType_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(1, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(633, 424);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.MistyRose;
            this.tabPage1.Controls.Add(this.IntakeTabReloadPatientButton);
            this.tabPage1.Controls.Add(this.groupBox8);
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Controls.Add(this.ButtonIntakeTabWritePatientFile);
            this.tabPage1.Controls.Add(this.groupBox11);
            this.tabPage1.Controls.Add(this.ButtonIntakeTabBeginNewForm);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(625, 398);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Intake";
            // 
            // IntakeTabReloadPatientButton
            // 
            this.IntakeTabReloadPatientButton.Location = new System.Drawing.Point(434, 372);
            this.IntakeTabReloadPatientButton.Name = "IntakeTabReloadPatientButton";
            this.IntakeTabReloadPatientButton.Size = new System.Drawing.Size(104, 23);
            this.IntakeTabReloadPatientButton.TabIndex = 21;
            this.IntakeTabReloadPatientButton.Text = "Reload Patient";
            this.IntakeTabReloadPatientButton.UseVisualStyleBackColor = true;
            this.IntakeTabReloadPatientButton.Click += new System.EventHandler(this.IntakeTabReloadPatientButton_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label98);
            this.groupBox8.Controls.Add(this.label97);
            this.groupBox8.Controls.Add(this.label96);
            this.groupBox8.Controls.Add(this.label95);
            this.groupBox8.Controls.Add(this.label45);
            this.groupBox8.Controls.Add(this.label43);
            this.groupBox8.Controls.Add(this.label44);
            this.groupBox8.Controls.Add(this.label42);
            this.groupBox8.Location = new System.Drawing.Point(329, 263);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(290, 108);
            this.groupBox8.TabIndex = 62;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Nutritional Status";
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(99, 84);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(41, 13);
            this.label98.TabIndex = 1003;
            this.label98.Text = "label98";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(99, 61);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(41, 13);
            this.label97.TabIndex = 1005;
            this.label97.Text = "label97";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(99, 38);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(41, 13);
            this.label96.TabIndex = 1006;
            this.label96.Text = "label96";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(99, 16);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(41, 13);
            this.label95.TabIndex = 1009;
            this.label95.Text = "label95";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(29, 16);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(64, 13);
            this.label45.TabIndex = 1008;
            this.label45.Text = "Height (cm):";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(64, 61);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(29, 13);
            this.label43.TabIndex = 1004;
            this.label43.Text = "BMI:";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(28, 38);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(65, 13);
            this.label44.TabIndex = 1007;
            this.label44.Text = "Weight (kg):";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(45, 84);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(48, 13);
            this.label42.TabIndex = 1001;
            this.label42.Text = "Z-Score:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label94);
            this.groupBox7.Controls.Add(this.label93);
            this.groupBox7.Controls.Add(this.label92);
            this.groupBox7.Controls.Add(this.label91);
            this.groupBox7.Controls.Add(this.label90);
            this.groupBox7.Controls.Add(this.label89);
            this.groupBox7.Controls.Add(this.label88);
            this.groupBox7.Controls.Add(this.label51);
            this.groupBox7.Controls.Add(this.label47);
            this.groupBox7.Controls.Add(this.label46);
            this.groupBox7.Controls.Add(this.label81);
            this.groupBox7.Controls.Add(this.label87);
            this.groupBox7.Controls.Add(this.label86);
            this.groupBox7.Controls.Add(this.label85);
            this.groupBox7.Controls.Add(this.label84);
            this.groupBox7.Controls.Add(this.label48);
            this.groupBox7.Controls.Add(this.label83);
            this.groupBox7.Controls.Add(this.label49);
            this.groupBox7.Controls.Add(this.label82);
            this.groupBox7.Controls.Add(this.label50);
            this.groupBox7.Location = new System.Drawing.Point(329, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(290, 251);
            this.groupBox7.TabIndex = 63;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Demographics";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(99, 219);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(41, 13);
            this.label94.TabIndex = 1011;
            this.label94.Text = "label94";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(99, 197);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(41, 13);
            this.label93.TabIndex = 61;
            this.label93.Text = "label93";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(99, 175);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(41, 13);
            this.label92.TabIndex = 60;
            this.label92.Text = "label92";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(99, 151);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(41, 13);
            this.label91.TabIndex = 59;
            this.label91.Text = "label91";
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(99, 129);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(41, 13);
            this.label90.TabIndex = 58;
            this.label90.Text = "label90";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(99, 107);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(41, 13);
            this.label89.TabIndex = 57;
            this.label89.Text = "label89";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(99, 85);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(41, 13);
            this.label88.TabIndex = 56;
            this.label88.Text = "label88";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(99, 62);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(41, 13);
            this.label51.TabIndex = 9;
            this.label51.Text = "label51";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(99, 39);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(41, 13);
            this.label47.TabIndex = 9;
            this.label47.Text = "label47";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(99, 19);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(41, 13);
            this.label46.TabIndex = 9;
            this.label46.Text = "label46";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(24, 16);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(69, 13);
            this.label81.TabIndex = 45;
            this.label81.Text = "Given Name:";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(15, 107);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(78, 13);
            this.label87.TabIndex = 53;
            this.label87.Text = "Estimated Age:";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(24, 151);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(69, 13);
            this.label86.TabIndex = 51;
            this.label86.Text = "Language(s):";
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(48, 62);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(45, 13);
            this.label85.TabIndex = 46;
            this.label85.Text = "Gender:";
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(30, 129);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(63, 13);
            this.label84.TabIndex = 52;
            this.label84.Text = "Stated Age:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(22, 85);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(71, 13);
            this.label48.TabIndex = 50;
            this.label48.Text = "Date Of Birth:";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(23, 39);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(70, 13);
            this.label83.TabIndex = 44;
            this.label83.Text = "Family Name:";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(6, 219);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(87, 13);
            this.label49.TabIndex = 1010;
            this.label49.Text = "Grade In School:";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(23, 173);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(70, 13);
            this.label82.TabIndex = 49;
            this.label82.Text = "Tribe/Village:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(5, 196);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(88, 13);
            this.label50.TabIndex = 47;
            this.label50.Text = "School/Teacher:";
            // 
            // ButtonIntakeTabWritePatientFile
            // 
            this.ButtonIntakeTabWritePatientFile.Location = new System.Drawing.Point(544, 372);
            this.ButtonIntakeTabWritePatientFile.Name = "ButtonIntakeTabWritePatientFile";
            this.ButtonIntakeTabWritePatientFile.Size = new System.Drawing.Size(75, 23);
            this.ButtonIntakeTabWritePatientFile.TabIndex = 19;
            this.ButtonIntakeTabWritePatientFile.Text = "Write File";
            this.ButtonIntakeTabWritePatientFile.UseVisualStyleBackColor = true;
            this.ButtonIntakeTabWritePatientFile.Click += new System.EventHandler(this.ButtonIntakeTabWritePatientFile_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabDOBDay);
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabDOBYear);
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabEstAgeYears);
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabStatedAgeYears);
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabDOBMonth);
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabStatedAgeMonths);
            this.groupBox11.Controls.Add(this.LabelIntakeTabDOB);
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabEstAgeMonths);
            this.groupBox11.Controls.Add(this.IntakeTabResetLanguageButton);
            this.groupBox11.Controls.Add(this.comboBox1);
            this.groupBox11.Controls.Add(this.ButtonSelectAgeType);
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabPatientLastNameIn);
            this.groupBox11.Controls.Add(this.ComboBoxIntakeTabSchoolList);
            this.groupBox11.Controls.Add(this.comboBox28);
            this.groupBox11.Controls.Add(this.textBox26);
            this.groupBox11.Controls.Add(this.textBox29);
            this.groupBox11.Controls.Add(this.textBox28);
            this.groupBox11.Controls.Add(this.label1);
            this.groupBox11.Controls.Add(this.LabelIntakeTabStatedAge);
            this.groupBox11.Controls.Add(this.textBox27);
            this.groupBox11.Controls.Add(this.ComboBoxIntakeTabStatusInSchool);
            this.groupBox11.Controls.Add(this.ComboBoxIntakeTabPresentVillage);
            this.groupBox11.Controls.Add(this.ComboBoxIntakeTabHomeVillage);
            this.groupBox11.Controls.Add(this.ComboBoxIntakeTabTribe);
            this.groupBox11.Controls.Add(this.TextBoxIntakeTabPatientFirstNameIn);
            this.groupBox11.Controls.Add(this.ComboBoxIntakeTabLanguageList);
            this.groupBox11.Controls.Add(this.GenderComboBox);
            this.groupBox11.Controls.Add(this.label99);
            this.groupBox11.Controls.Add(this.label77);
            this.groupBox11.Controls.Add(this.label78);
            this.groupBox11.Controls.Add(this.label79);
            this.groupBox11.Controls.Add(this.label80);
            this.groupBox11.Controls.Add(this.LabelIntakeTabSchoolStatus);
            this.groupBox11.Controls.Add(this.LabelIntakeTabPresentVillage);
            this.groupBox11.Controls.Add(this.LabelIntakeTabSchoolYear);
            this.groupBox11.Controls.Add(this.LabelIntakeTabeHomeVillage);
            this.groupBox11.Controls.Add(this.LabelIntakeTabSchoolName);
            this.groupBox11.Controls.Add(this.LabelIntakeTabLastName);
            this.groupBox11.Controls.Add(this.LabelIntakeTabTribe);
            this.groupBox11.Controls.Add(this.LabelIntakeTabFirstName);
            this.groupBox11.Controls.Add(this.ButtonIntakeTabAddLanguage);
            this.groupBox11.Controls.Add(this.LabelIntakePatientGender);
            this.groupBox11.Controls.Add(this.LabelIntakeTabLanguage);
            this.groupBox11.Location = new System.Drawing.Point(6, 6);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(317, 383);
            this.groupBox11.TabIndex = 40;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Edit Demographics";
            // 
            // TextBoxIntakeTabDOBDay
            // 
            this.TextBoxIntakeTabDOBDay.Location = new System.Drawing.Point(275, 68);
            this.TextBoxIntakeTabDOBDay.Name = "TextBoxIntakeTabDOBDay";
            this.TextBoxIntakeTabDOBDay.Size = new System.Drawing.Size(33, 20);
            this.TextBoxIntakeTabDOBDay.TabIndex = 5;
            this.TextBoxIntakeTabDOBDay.TextChanged += new System.EventHandler(this.TextBoxIntakeTabDOBDay_TextChanged);
            // 
            // TextBoxIntakeTabDOBYear
            // 
            this.TextBoxIntakeTabDOBYear.Location = new System.Drawing.Point(134, 68);
            this.TextBoxIntakeTabDOBYear.Name = "TextBoxIntakeTabDOBYear";
            this.TextBoxIntakeTabDOBYear.Size = new System.Drawing.Size(36, 20);
            this.TextBoxIntakeTabDOBYear.TabIndex = 25;
            this.TextBoxIntakeTabDOBYear.TextChanged += new System.EventHandler(this.TextBoxIntakeTabDOBYear_TextChanged);
            // 
            // TextBoxIntakeTabEstAgeYears
            // 
            this.TextBoxIntakeTabEstAgeYears.Location = new System.Drawing.Point(142, 55);
            this.TextBoxIntakeTabEstAgeYears.Name = "TextBoxIntakeTabEstAgeYears";
            this.TextBoxIntakeTabEstAgeYears.Size = new System.Drawing.Size(33, 20);
            this.TextBoxIntakeTabEstAgeYears.TabIndex = 4;
            this.TextBoxIntakeTabEstAgeYears.TextChanged += new System.EventHandler(this.TextBoxIntakeTabEstAgeYears_TextChanged);
            // 
            // TextBoxIntakeTabStatedAgeYears
            // 
            this.TextBoxIntakeTabStatedAgeYears.Location = new System.Drawing.Point(142, 79);
            this.TextBoxIntakeTabStatedAgeYears.Name = "TextBoxIntakeTabStatedAgeYears";
            this.TextBoxIntakeTabStatedAgeYears.Size = new System.Drawing.Size(33, 20);
            this.TextBoxIntakeTabStatedAgeYears.TabIndex = 6;
            this.TextBoxIntakeTabStatedAgeYears.TextChanged += new System.EventHandler(this.TextBoxIntakeTabStatedAgeYears_TextChanged);
            // 
            // TextBoxIntakeTabDOBMonth
            // 
            this.TextBoxIntakeTabDOBMonth.Location = new System.Drawing.Point(212, 68);
            this.TextBoxIntakeTabDOBMonth.Name = "TextBoxIntakeTabDOBMonth";
            this.TextBoxIntakeTabDOBMonth.Size = new System.Drawing.Size(33, 20);
            this.TextBoxIntakeTabDOBMonth.TabIndex = 6;
            this.TextBoxIntakeTabDOBMonth.TextChanged += new System.EventHandler(this.TextBoxIntakeTabDOBMonth_TextChanged);
            // 
            // TextBoxIntakeTabStatedAgeMonths
            // 
            this.TextBoxIntakeTabStatedAgeMonths.Location = new System.Drawing.Point(217, 80);
            this.TextBoxIntakeTabStatedAgeMonths.Name = "TextBoxIntakeTabStatedAgeMonths";
            this.TextBoxIntakeTabStatedAgeMonths.Size = new System.Drawing.Size(42, 20);
            this.TextBoxIntakeTabStatedAgeMonths.TabIndex = 7;
            this.TextBoxIntakeTabStatedAgeMonths.TextChanged += new System.EventHandler(this.TextBoxIntakeTabStatedAgeMonths_TextChanged);
            // 
            // LabelIntakeTabDOB
            // 
            this.LabelIntakeTabDOB.AutoSize = true;
            this.LabelIntakeTabDOB.Location = new System.Drawing.Point(13, 71);
            this.LabelIntakeTabDOB.Name = "LabelIntakeTabDOB";
            this.LabelIntakeTabDOB.Size = new System.Drawing.Size(265, 13);
            this.LabelIntakeTabDOB.TabIndex = 32;
            this.LabelIntakeTabDOB.Text = "DOB (if available):  Year:               Month:              Day:";
            // 
            // TextBoxIntakeTabEstAgeMonths
            // 
            this.TextBoxIntakeTabEstAgeMonths.Location = new System.Drawing.Point(217, 55);
            this.TextBoxIntakeTabEstAgeMonths.Name = "TextBoxIntakeTabEstAgeMonths";
            this.TextBoxIntakeTabEstAgeMonths.Size = new System.Drawing.Size(42, 20);
            this.TextBoxIntakeTabEstAgeMonths.TabIndex = 5;
            this.TextBoxIntakeTabEstAgeMonths.TextChanged += new System.EventHandler(this.TextBoxIntakeTabEstAgeMonths_TextChanged);
            // 
            // IntakeTabResetLanguageButton
            // 
            this.IntakeTabResetLanguageButton.Location = new System.Drawing.Point(186, 162);
            this.IntakeTabResetLanguageButton.Name = "IntakeTabResetLanguageButton";
            this.IntakeTabResetLanguageButton.Size = new System.Drawing.Size(102, 23);
            this.IntakeTabResetLanguageButton.TabIndex = 24;
            this.IntakeTabResetLanguageButton.TabStop = false;
            this.IntakeTabResetLanguageButton.Text = "Reset Languages";
            this.IntakeTabResetLanguageButton.UseVisualStyleBackColor = true;
            this.IntakeTabResetLanguageButton.Click += new System.EventHandler(this.IntakeTabResetLanguageButton_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(250, 302);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(52, 21);
            this.comboBox1.TabIndex = 15;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // ButtonSelectAgeType
            // 
            this.ButtonSelectAgeType.Location = new System.Drawing.Point(81, 107);
            this.ButtonSelectAgeType.Name = "ButtonSelectAgeType";
            this.ButtonSelectAgeType.Size = new System.Drawing.Size(159, 23);
            this.ButtonSelectAgeType.TabIndex = 22;
            this.ButtonSelectAgeType.TabStop = false;
            this.ButtonSelectAgeType.Text = "Enter Date Of Birth";
            this.ButtonSelectAgeType.UseVisualStyleBackColor = true;
            this.ButtonSelectAgeType.Click += new System.EventHandler(this.ButtonSelectAgeType_Click);
            // 
            // TextBoxIntakeTabPatientLastNameIn
            // 
            this.TextBoxIntakeTabPatientLastNameIn.Location = new System.Drawing.Point(124, 32);
            this.TextBoxIntakeTabPatientLastNameIn.Name = "TextBoxIntakeTabPatientLastNameIn";
            this.TextBoxIntakeTabPatientLastNameIn.Size = new System.Drawing.Size(100, 20);
            this.TextBoxIntakeTabPatientLastNameIn.TabIndex = 2;
            this.TextBoxIntakeTabPatientLastNameIn.TextChanged += new System.EventHandler(this.TextBoxIntakeTabPatientLastNameIn_TextChanged);
            // 
            // ComboBoxIntakeTabSchoolList
            // 
            this.ComboBoxIntakeTabSchoolList.FormattingEnabled = true;
            this.ComboBoxIntakeTabSchoolList.Location = new System.Drawing.Point(43, 302);
            this.ComboBoxIntakeTabSchoolList.Name = "ComboBoxIntakeTabSchoolList";
            this.ComboBoxIntakeTabSchoolList.Size = new System.Drawing.Size(114, 21);
            this.ComboBoxIntakeTabSchoolList.TabIndex = 14;
            this.ComboBoxIntakeTabSchoolList.SelectedIndexChanged += new System.EventHandler(this.ComboBoxIntakeTabSchoolList_SelectedIndexChanged);
            this.ComboBoxIntakeTabSchoolList.TextChanged += new System.EventHandler(this.ComboBoxIntakeTabSchoolList_SelectedIndexChanged);
            // 
            // comboBox28
            // 
            this.comboBox28.FormattingEnabled = true;
            this.comboBox28.Location = new System.Drawing.Point(50, 275);
            this.comboBox28.Name = "comboBox28";
            this.comboBox28.Size = new System.Drawing.Size(149, 21);
            this.comboBox28.TabIndex = 12;
            this.comboBox28.SelectedIndexChanged += new System.EventHandler(this.comboBox28_TextChanged);
            this.comboBox28.TextChanged += new System.EventHandler(this.comboBox28_TextChanged);
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(77, 355);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(80, 20);
            this.textBox26.TabIndex = 17;
            this.textBox26.TextChanged += new System.EventHandler(this.textBox26_TextChanged);
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(77, 329);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(80, 20);
            this.textBox29.TabIndex = 16;
            this.textBox29.TextChanged += new System.EventHandler(this.textBox29_TextChanged);
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(212, 329);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(80, 20);
            this.textBox28.TabIndex = 18;
            this.textBox28.TextChanged += new System.EventHandler(this.textBox28_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(188, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "Estimated Age:  Years:            Months:";
            // 
            // LabelIntakeTabStatedAge
            // 
            this.LabelIntakeTabStatedAge.AutoSize = true;
            this.LabelIntakeTabStatedAge.Location = new System.Drawing.Point(47, 83);
            this.LabelIntakeTabStatedAge.Name = "LabelIntakeTabStatedAge";
            this.LabelIntakeTabStatedAge.Size = new System.Drawing.Size(173, 13);
            this.LabelIntakeTabStatedAge.TabIndex = 33;
            this.LabelIntakeTabStatedAge.Text = "Stated Age:  Years:            Months:";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(212, 356);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(80, 20);
            this.textBox27.TabIndex = 19;
            this.textBox27.TextChanged += new System.EventHandler(this.textBox27_TextChanged);
            // 
            // ComboBoxIntakeTabStatusInSchool
            // 
            this.ComboBoxIntakeTabStatusInSchool.FormattingEnabled = true;
            this.ComboBoxIntakeTabStatusInSchool.Location = new System.Drawing.Point(235, 275);
            this.ComboBoxIntakeTabStatusInSchool.Name = "ComboBoxIntakeTabStatusInSchool";
            this.ComboBoxIntakeTabStatusInSchool.Size = new System.Drawing.Size(67, 21);
            this.ComboBoxIntakeTabStatusInSchool.TabIndex = 13;
            // 
            // ComboBoxIntakeTabPresentVillage
            // 
            this.ComboBoxIntakeTabPresentVillage.FormattingEnabled = true;
            this.ComboBoxIntakeTabPresentVillage.Location = new System.Drawing.Point(130, 248);
            this.ComboBoxIntakeTabPresentVillage.Name = "ComboBoxIntakeTabPresentVillage";
            this.ComboBoxIntakeTabPresentVillage.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxIntakeTabPresentVillage.TabIndex = 11;
            this.ComboBoxIntakeTabPresentVillage.SelectedIndexChanged += new System.EventHandler(this.ComboBoxIntakeTabTribe_textChanged);
            // 
            // ComboBoxIntakeTabHomeVillage
            // 
            this.ComboBoxIntakeTabHomeVillage.FormattingEnabled = true;
            this.ComboBoxIntakeTabHomeVillage.Location = new System.Drawing.Point(129, 221);
            this.ComboBoxIntakeTabHomeVillage.Name = "ComboBoxIntakeTabHomeVillage";
            this.ComboBoxIntakeTabHomeVillage.Size = new System.Drawing.Size(122, 21);
            this.ComboBoxIntakeTabHomeVillage.TabIndex = 10;
            // 
            // ComboBoxIntakeTabTribe
            // 
            this.ComboBoxIntakeTabTribe.FormattingEnabled = true;
            this.ComboBoxIntakeTabTribe.Location = new System.Drawing.Point(129, 194);
            this.ComboBoxIntakeTabTribe.Name = "ComboBoxIntakeTabTribe";
            this.ComboBoxIntakeTabTribe.Size = new System.Drawing.Size(122, 21);
            this.ComboBoxIntakeTabTribe.TabIndex = 9;
            this.ComboBoxIntakeTabTribe.TextChanged += new System.EventHandler(this.ComboBoxIntakeTabTribe_textChanged);
            // 
            // TextBoxIntakeTabPatientFirstNameIn
            // 
            this.TextBoxIntakeTabPatientFirstNameIn.Location = new System.Drawing.Point(4, 32);
            this.TextBoxIntakeTabPatientFirstNameIn.Name = "TextBoxIntakeTabPatientFirstNameIn";
            this.TextBoxIntakeTabPatientFirstNameIn.Size = new System.Drawing.Size(100, 20);
            this.TextBoxIntakeTabPatientFirstNameIn.TabIndex = 1;
            this.TextBoxIntakeTabPatientFirstNameIn.TextChanged += new System.EventHandler(this.TextBoxIntakeTabPatientFirstNameIn_TextChanged);
            // 
            // ComboBoxIntakeTabLanguageList
            // 
            this.ComboBoxIntakeTabLanguageList.FormattingEnabled = true;
            this.ComboBoxIntakeTabLanguageList.Location = new System.Drawing.Point(90, 135);
            this.ComboBoxIntakeTabLanguageList.Name = "ComboBoxIntakeTabLanguageList";
            this.ComboBoxIntakeTabLanguageList.Size = new System.Drawing.Size(202, 21);
            this.ComboBoxIntakeTabLanguageList.TabIndex = 8;
            // 
            // GenderComboBox
            // 
            this.GenderComboBox.FormattingEnabled = true;
            this.GenderComboBox.Location = new System.Drawing.Point(250, 32);
            this.GenderComboBox.Name = "GenderComboBox";
            this.GenderComboBox.Size = new System.Drawing.Size(38, 21);
            this.GenderComboBox.TabIndex = 3;
            this.GenderComboBox.SelectedIndexChanged += new System.EventHandler(this.GenderComboBox_SelectedIndexChanged);
            this.GenderComboBox.TextChanged += new System.EventHandler(this.GenderComboBox_SelectedIndexChanged);
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(1, 278);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(50, 13);
            this.label99.TabIndex = 48;
            this.label99.Text = "Teacher:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(158, 359);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(48, 13);
            this.label77.TabIndex = 40;
            this.label77.Text = "Z-Score:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(177, 335);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(29, 13);
            this.label78.TabIndex = 41;
            this.label78.Text = "BMI:";
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(11, 359);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(65, 13);
            this.label79.TabIndex = 42;
            this.label79.Text = "Weight (kg):";
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(12, 332);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(64, 13);
            this.label80.TabIndex = 43;
            this.label80.Text = "Height (cm):";
            // 
            // LabelIntakeTabSchoolStatus
            // 
            this.LabelIntakeTabSchoolStatus.AutoSize = true;
            this.LabelIntakeTabSchoolStatus.Location = new System.Drawing.Point(199, 278);
            this.LabelIntakeTabSchoolStatus.Name = "LabelIntakeTabSchoolStatus";
            this.LabelIntakeTabSchoolStatus.Size = new System.Drawing.Size(40, 13);
            this.LabelIntakeTabSchoolStatus.TabIndex = 34;
            this.LabelIntakeTabSchoolStatus.Text = "Status:";
            // 
            // LabelIntakeTabPresentVillage
            // 
            this.LabelIntakeTabPresentVillage.AutoSize = true;
            this.LabelIntakeTabPresentVillage.Location = new System.Drawing.Point(53, 251);
            this.LabelIntakeTabPresentVillage.Name = "LabelIntakeTabPresentVillage";
            this.LabelIntakeTabPresentVillage.Size = new System.Drawing.Size(80, 13);
            this.LabelIntakeTabPresentVillage.TabIndex = 37;
            this.LabelIntakeTabPresentVillage.Text = "Present Village:";
            // 
            // LabelIntakeTabSchoolYear
            // 
            this.LabelIntakeTabSchoolYear.AutoSize = true;
            this.LabelIntakeTabSchoolYear.Location = new System.Drawing.Point(170, 305);
            this.LabelIntakeTabSchoolYear.Name = "LabelIntakeTabSchoolYear";
            this.LabelIntakeTabSchoolYear.Size = new System.Drawing.Size(77, 13);
            this.LabelIntakeTabSchoolYear.TabIndex = 32;
            this.LabelIntakeTabSchoolYear.Text = "Year In School";
            // 
            // LabelIntakeTabeHomeVillage
            // 
            this.LabelIntakeTabeHomeVillage.AutoSize = true;
            this.LabelIntakeTabeHomeVillage.Location = new System.Drawing.Point(61, 224);
            this.LabelIntakeTabeHomeVillage.Name = "LabelIntakeTabeHomeVillage";
            this.LabelIntakeTabeHomeVillage.Size = new System.Drawing.Size(72, 13);
            this.LabelIntakeTabeHomeVillage.TabIndex = 36;
            this.LabelIntakeTabeHomeVillage.Text = "Home Village:";
            // 
            // LabelIntakeTabSchoolName
            // 
            this.LabelIntakeTabSchoolName.AutoSize = true;
            this.LabelIntakeTabSchoolName.Location = new System.Drawing.Point(5, 305);
            this.LabelIntakeTabSchoolName.Name = "LabelIntakeTabSchoolName";
            this.LabelIntakeTabSchoolName.Size = new System.Drawing.Size(43, 13);
            this.LabelIntakeTabSchoolName.TabIndex = 30;
            this.LabelIntakeTabSchoolName.Text = "School:";
            // 
            // LabelIntakeTabLastName
            // 
            this.LabelIntakeTabLastName.AutoSize = true;
            this.LabelIntakeTabLastName.Location = new System.Drawing.Point(19, 16);
            this.LabelIntakeTabLastName.Name = "LabelIntakeTabLastName";
            this.LabelIntakeTabLastName.Size = new System.Drawing.Size(69, 13);
            this.LabelIntakeTabLastName.TabIndex = 28;
            this.LabelIntakeTabLastName.Text = "Given Name:";
            // 
            // LabelIntakeTabTribe
            // 
            this.LabelIntakeTabTribe.AutoSize = true;
            this.LabelIntakeTabTribe.Location = new System.Drawing.Point(99, 197);
            this.LabelIntakeTabTribe.Name = "LabelIntakeTabTribe";
            this.LabelIntakeTabTribe.Size = new System.Drawing.Size(34, 13);
            this.LabelIntakeTabTribe.TabIndex = 35;
            this.LabelIntakeTabTribe.Text = "Tribe:";
            // 
            // LabelIntakeTabFirstName
            // 
            this.LabelIntakeTabFirstName.AutoSize = true;
            this.LabelIntakeTabFirstName.Location = new System.Drawing.Point(139, 16);
            this.LabelIntakeTabFirstName.Name = "LabelIntakeTabFirstName";
            this.LabelIntakeTabFirstName.Size = new System.Drawing.Size(70, 13);
            this.LabelIntakeTabFirstName.TabIndex = 29;
            this.LabelIntakeTabFirstName.Text = "Family Name:";
            // 
            // ButtonIntakeTabAddLanguage
            // 
            this.ButtonIntakeTabAddLanguage.Location = new System.Drawing.Point(60, 162);
            this.ButtonIntakeTabAddLanguage.Name = "ButtonIntakeTabAddLanguage";
            this.ButtonIntakeTabAddLanguage.Size = new System.Drawing.Size(102, 23);
            this.ButtonIntakeTabAddLanguage.TabIndex = 23;
            this.ButtonIntakeTabAddLanguage.TabStop = false;
            this.ButtonIntakeTabAddLanguage.Text = "Add Language";
            this.ButtonIntakeTabAddLanguage.UseVisualStyleBackColor = true;
            this.ButtonIntakeTabAddLanguage.Click += new System.EventHandler(this.ButtonIntakeTabAddLanguage_Click);
            // 
            // LabelIntakePatientGender
            // 
            this.LabelIntakePatientGender.AutoSize = true;
            this.LabelIntakePatientGender.Location = new System.Drawing.Point(247, 16);
            this.LabelIntakePatientGender.Name = "LabelIntakePatientGender";
            this.LabelIntakePatientGender.Size = new System.Drawing.Size(45, 13);
            this.LabelIntakePatientGender.TabIndex = 30;
            this.LabelIntakePatientGender.Text = "Gender:";
            // 
            // LabelIntakeTabLanguage
            // 
            this.LabelIntakeTabLanguage.AutoSize = true;
            this.LabelIntakeTabLanguage.Location = new System.Drawing.Point(19, 138);
            this.LabelIntakeTabLanguage.Name = "LabelIntakeTabLanguage";
            this.LabelIntakeTabLanguage.Size = new System.Drawing.Size(58, 13);
            this.LabelIntakeTabLanguage.TabIndex = 34;
            this.LabelIntakeTabLanguage.Text = "Language:";
            // 
            // ButtonIntakeTabBeginNewForm
            // 
            this.ButtonIntakeTabBeginNewForm.Location = new System.Drawing.Point(329, 372);
            this.ButtonIntakeTabBeginNewForm.Name = "ButtonIntakeTabBeginNewForm";
            this.ButtonIntakeTabBeginNewForm.Size = new System.Drawing.Size(99, 23);
            this.ButtonIntakeTabBeginNewForm.TabIndex = 20;
            this.ButtonIntakeTabBeginNewForm.TabStop = false;
            this.ButtonIntakeTabBeginNewForm.Text = "New Patient";
            this.ButtonIntakeTabBeginNewForm.UseVisualStyleBackColor = true;
            this.ButtonIntakeTabBeginNewForm.Click += new System.EventHandler(this.ButtonIntakeTabBeginNewForm_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Lavender;
            this.tabPage2.Controls.Add(this.button12);
            this.tabPage2.Controls.Add(this.button11);
            this.tabPage2.Controls.Add(this.TriageTabChiefComplaintInput);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox13);
            this.tabPage2.Controls.Add(this.groupBox10);
            this.tabPage2.Controls.Add(this.groupBox12);
            this.tabPage2.Controls.Add(this.TriageTabToggle);
            this.tabPage2.Controls.Add(this.button9);
            this.tabPage2.Controls.Add(this.label40);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.label33);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(625, 398);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Triage";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(547, 372);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(72, 20);
            this.button12.TabIndex = 45;
            this.button12.Text = "Scroll Down";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(473, 372);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 20);
            this.button11.TabIndex = 44;
            this.button11.Text = "Scroll Up";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // TriageTabChiefComplaintInput
            // 
            this.TriageTabChiefComplaintInput.Location = new System.Drawing.Point(85, 110);
            this.TriageTabChiefComplaintInput.Name = "TriageTabChiefComplaintInput";
            this.TriageTabChiefComplaintInput.Size = new System.Drawing.Size(263, 20);
            this.TriageTabChiefComplaintInput.TabIndex = 17;
            this.TriageTabChiefComplaintInput.TextChanged += new System.EventHandler(this.TriageTabChiefComplaintInput_TextChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label128);
            this.groupBox6.Controls.Add(this.label127);
            this.groupBox6.Controls.Add(this.textBox18);
            this.groupBox6.Controls.Add(this.textBox23);
            this.groupBox6.Controls.Add(this.textBox22);
            this.groupBox6.Controls.Add(this.textBox21);
            this.groupBox6.Controls.Add(this.textBox20);
            this.groupBox6.Controls.Add(this.textBox19);
            this.groupBox6.Controls.Add(this.textBox17);
            this.groupBox6.Controls.Add(this.textBox16);
            this.groupBox6.Controls.Add(this.label68);
            this.groupBox6.Controls.Add(this.label41);
            this.groupBox6.Controls.Add(this.label58);
            this.groupBox6.Controls.Add(this.label59);
            this.groupBox6.Controls.Add(this.label61);
            this.groupBox6.Controls.Add(this.label66);
            this.groupBox6.Controls.Add(this.label63);
            this.groupBox6.Controls.Add(this.label64);
            this.groupBox6.Controls.Add(this.label65);
            this.groupBox6.Location = new System.Drawing.Point(3, 136);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(345, 236);
            this.groupBox6.TabIndex = 40;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Red Flags:";
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(54, 173);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(69, 13);
            this.label128.TabIndex = 39;
            this.label128.Text = "Severe pallor";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(42, 194);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(66, 13);
            this.label127.TabIndex = 38;
            this.label127.Text = "Current/prior";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(126, 123);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(213, 20);
            this.textBox18.TabIndex = 29;
            this.textBox18.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(126, 97);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(213, 20);
            this.textBox23.TabIndex = 34;
            this.textBox23.TextChanged += new System.EventHandler(this.textBox23_TextChanged);
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(126, 71);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(213, 20);
            this.textBox22.TabIndex = 33;
            this.textBox22.TextChanged += new System.EventHandler(this.textBox22_TextChanged);
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(126, 45);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(213, 20);
            this.textBox21.TabIndex = 32;
            this.textBox21.TextChanged += new System.EventHandler(this.textBox21_TextChanged);
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(126, 19);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(213, 20);
            this.textBox20.TabIndex = 31;
            this.textBox20.TextChanged += new System.EventHandler(this.textBox20_TextChanged);
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(126, 198);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(213, 20);
            this.textBox19.TabIndex = 30;
            this.textBox19.TextChanged += new System.EventHandler(this.textBox19_TextChanged);
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(126, 149);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(213, 20);
            this.textBox17.TabIndex = 28;
            this.textBox17.TextChanged += new System.EventHandler(this.textBox17_TextChanged);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(126, 175);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(213, 20);
            this.textBox16.TabIndex = 27;
            this.textBox16.TextChanged += new System.EventHandler(this.textBox16_TextChanged);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(31, 206);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(96, 13);
            this.label68.TabIndex = 37;
            this.label68.Text = "intestinal parasites:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(42, 22);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(88, 13);
            this.label41.TabIndex = 19;
            this.label41.Text = "Cough/Dyspnea:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(5, 48);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(125, 13);
            this.label58.TabIndex = 20;
            this.label58.Text = "Diarrhea +/- dehydration:";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(26, 74);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(104, 13);
            this.label59.TabIndex = 21;
            this.label59.Text = "Fever and stiff neck:";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(61, 100);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(69, 13);
            this.label61.TabIndex = 22;
            this.label61.Text = "e/o Measles:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(5, 158);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(125, 13);
            this.label66.TabIndex = 35;
            this.label66.Text = "FHx blindness/trachoma:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(65, 183);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(66, 13);
            this.label63.TabIndex = 24;
            this.label63.Text = "c/w anemia:";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(55, 145);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(75, 13);
            this.label64.TabIndex = 25;
            this.label64.Text = "Eye problems/";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(6, 126);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(124, 13);
            this.label65.TabIndex = 26;
            this.label65.Text = "Ear problems/mastoiditis:";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label116);
            this.groupBox13.Controls.Add(this.label115);
            this.groupBox13.Controls.Add(this.label114);
            this.groupBox13.Controls.Add(this.label113);
            this.groupBox13.Controls.Add(this.label112);
            this.groupBox13.Controls.Add(this.label111);
            this.groupBox13.Controls.Add(this.label110);
            this.groupBox13.Controls.Add(this.label109);
            this.groupBox13.Controls.Add(this.label108);
            this.groupBox13.Controls.Add(this.label107);
            this.groupBox13.Controls.Add(this.label106);
            this.groupBox13.Controls.Add(this.label105);
            this.groupBox13.Controls.Add(this.label104);
            this.groupBox13.Controls.Add(this.label103);
            this.groupBox13.Controls.Add(this.label102);
            this.groupBox13.Controls.Add(this.label101);
            this.groupBox13.Controls.Add(this.label100);
            this.groupBox13.Controls.Add(this.label75);
            this.groupBox13.Controls.Add(this.label74);
            this.groupBox13.Location = new System.Drawing.Point(357, 86);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(265, 286);
            this.groupBox13.TabIndex = 12;
            this.groupBox13.TabStop = false;
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(6, 267);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(47, 13);
            this.label116.TabIndex = 19;
            this.label116.Text = "label116";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(6, 252);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(47, 13);
            this.label115.TabIndex = 18;
            this.label115.Text = "label115";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(6, 237);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(47, 13);
            this.label114.TabIndex = 17;
            this.label114.Text = "label114";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(6, 222);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(47, 13);
            this.label113.TabIndex = 16;
            this.label113.Text = "label113";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(6, 207);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(47, 13);
            this.label112.TabIndex = 15;
            this.label112.Text = "label112";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(6, 191);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(47, 13);
            this.label111.TabIndex = 14;
            this.label111.Text = "label111";
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(6, 176);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(47, 13);
            this.label110.TabIndex = 13;
            this.label110.Text = "label110";
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(6, 161);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(47, 13);
            this.label109.TabIndex = 12;
            this.label109.Text = "label109";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(6, 146);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(47, 13);
            this.label108.TabIndex = 11;
            this.label108.Text = "label108";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(6, 131);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(47, 13);
            this.label107.TabIndex = 10;
            this.label107.Text = "label107";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(6, 116);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(47, 13);
            this.label106.TabIndex = 9;
            this.label106.Text = "label106";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(6, 101);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(47, 13);
            this.label105.TabIndex = 8;
            this.label105.Text = "label105";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(6, 86);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(47, 13);
            this.label104.TabIndex = 7;
            this.label104.Text = "label104";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(6, 71);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(47, 13);
            this.label103.TabIndex = 6;
            this.label103.Text = "label103";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(6, 56);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(47, 13);
            this.label102.TabIndex = 5;
            this.label102.Text = "label102";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(6, 41);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(47, 13);
            this.label101.TabIndex = 4;
            this.label101.Text = "label101";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(6, 26);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(47, 13);
            this.label100.TabIndex = 3;
            this.label100.Text = "label100";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(27, 9);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(41, 13);
            this.label75.TabIndex = 1;
            this.label75.Text = "label75";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(6, 9);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(24, 13);
            this.label74.TabIndex = 0;
            this.label74.Text = "CC:";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.textBox32);
            this.groupBox10.Controls.Add(this.textBox31);
            this.groupBox10.Controls.Add(this.textBox30);
            this.groupBox10.Controls.Add(this.textBox25);
            this.groupBox10.Controls.Add(this.label71);
            this.groupBox10.Controls.Add(this.label70);
            this.groupBox10.Controls.Add(this.label69);
            this.groupBox10.Controls.Add(this.label67);
            this.groupBox10.Controls.Add(this.textBox24);
            this.groupBox10.Controls.Add(this.label62);
            this.groupBox10.Controls.Add(this.button10);
            this.groupBox10.Location = new System.Drawing.Point(85, 90);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(230, 125);
            this.groupBox10.TabIndex = 11;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Vitals";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(71, 56);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(53, 20);
            this.textBox32.TabIndex = 45;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(71, 98);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(53, 20);
            this.textBox31.TabIndex = 44;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(71, 77);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(53, 20);
            this.textBox30.TabIndex = 43;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(71, 35);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(53, 20);
            this.textBox25.TabIndex = 42;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(22, 101);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(43, 13);
            this.label71.TabIndex = 41;
            this.label71.Text = "O2 Sat:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(41, 80);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(24, 13);
            this.label70.TabIndex = 40;
            this.label70.Text = "BP:";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(48, 59);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(17, 13);
            this.label69.TabIndex = 39;
            this.label69.Text = "P:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(48, 38);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(17, 13);
            this.label67.TabIndex = 38;
            this.label67.Text = "T:";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(50, 13);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(174, 20);
            this.textBox24.TabIndex = 2;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(3, 16);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(51, 13);
            this.label62.TabIndex = 1;
            this.label62.Text = "Situation:";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(142, 62);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(75, 23);
            this.button10.TabIndex = 0;
            this.button10.Text = "Add Vitals";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label73);
            this.groupBox12.Controls.Add(this.label72);
            this.groupBox12.Controls.Add(this.textBox37);
            this.groupBox12.Controls.Add(this.textBox36);
            this.groupBox12.Controls.Add(this.textBox35);
            this.groupBox12.Controls.Add(this.textBox34);
            this.groupBox12.Controls.Add(this.textBox33);
            this.groupBox12.Controls.Add(this.checkBox5);
            this.groupBox12.Controls.Add(this.checkBox4);
            this.groupBox12.Controls.Add(this.checkBox3);
            this.groupBox12.Controls.Add(this.checkBox2);
            this.groupBox12.Controls.Add(this.checkBox1);
            this.groupBox12.Location = new System.Drawing.Point(85, 218);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(230, 148);
            this.groupBox12.TabIndex = 43;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "WHO Vaccines Given";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(113, 19);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(111, 13);
            this.label73.TabIndex = 11;
            this.label73.Text = "Est. Date (MM/YYYY)";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(13, 19);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(76, 13);
            this.label72.TabIndex = 10;
            this.label72.Text = "WHO Vaccine";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(140, 123);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(82, 20);
            this.textBox37.TabIndex = 9;
            this.textBox37.TextChanged += new System.EventHandler(this.textBox37_TextChanged);
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(140, 102);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(82, 20);
            this.textBox36.TabIndex = 8;
            this.textBox36.TextChanged += new System.EventHandler(this.textBox36_TextChanged);
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(140, 79);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(82, 20);
            this.textBox35.TabIndex = 7;
            this.textBox35.TextChanged += new System.EventHandler(this.textBox35_TextChanged);
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(140, 56);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(82, 20);
            this.textBox34.TabIndex = 6;
            this.textBox34.TextChanged += new System.EventHandler(this.textBox34_TextChanged);
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(140, 33);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(82, 20);
            this.textBox33.TabIndex = 5;
            this.textBox33.TextChanged += new System.EventHandler(this.textBox33_TextChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(9, 125);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(132, 17);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.Text = "Measles, Yellow Fever";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(9, 104);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(131, 17);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "DPT-3, OPV-3, HBV-3";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(9, 81);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(131, 17);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "DPT-2, OPV-2, HBV-2";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(9, 58);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(131, 17);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "DPT-1, OPV-1, HBV-1";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(9, 35);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(85, 17);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "BCG, OPV-0";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // TriageTabToggle
            // 
            this.TriageTabToggle.Location = new System.Drawing.Point(3, 374);
            this.TriageTabToggle.Name = "TriageTabToggle";
            this.TriageTabToggle.Size = new System.Drawing.Size(210, 23);
            this.TriageTabToggle.TabIndex = 42;
            this.TriageTabToggle.Text = "Edit Vaccines and Vitals";
            this.TriageTabToggle.UseVisualStyleBackColor = true;
            this.TriageTabToggle.Click += new System.EventHandler(this.TriageTabToggle_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(357, 374);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(91, 23);
            this.button9.TabIndex = 41;
            this.button9.Text = "Update Patient";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(7, 124);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(0, 13);
            this.label40.TabIndex = 18;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(260, 374);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(91, 23);
            this.button8.TabIndex = 16;
            this.button8.Text = "Load Patient";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label34);
            this.groupBox5.Controls.Add(this.label35);
            this.groupBox5.Controls.Add(this.label36);
            this.groupBox5.Controls.Add(this.label37);
            this.groupBox5.Controls.Add(this.label38);
            this.groupBox5.Controls.Add(this.label39);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(613, 78);
            this.groupBox5.TabIndex = 15;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Current Patient";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(6, 16);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 13);
            this.label34.TabIndex = 1;
            this.label34.Text = "label34";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(336, 60);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 13);
            this.label35.TabIndex = 13;
            this.label35.Text = "label35";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(6, 60);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(41, 13);
            this.label36.TabIndex = 10;
            this.label36.Text = "label36";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(336, 38);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(41, 13);
            this.label37.TabIndex = 12;
            this.label37.Text = "label37";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 38);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(41, 13);
            this.label38.TabIndex = 9;
            this.label38.Text = "label38";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(336, 16);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(41, 13);
            this.label39.TabIndex = 11;
            this.label39.Text = "label39";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(6, 113);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(83, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "Chief Complaint:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.PaleTurquoise;
            this.tabPage3.Controls.Add(this.groupBox16);
            this.tabPage3.Controls.Add(this.label32);
            this.tabPage3.Controls.Add(this.button14);
            this.tabPage3.Controls.Add(this.richTextBox3);
            this.tabPage3.Controls.Add(this.label125);
            this.tabPage3.Controls.Add(this.label124);
            this.tabPage3.Controls.Add(this.button17);
            this.tabPage3.Controls.Add(this.label123);
            this.tabPage3.Controls.Add(this.label122);
            this.tabPage3.Controls.Add(this.label121);
            this.tabPage3.Controls.Add(this.label76);
            this.tabPage3.Controls.Add(this.richTextBox2);
            this.tabPage3.Controls.Add(this.button16);
            this.tabPage3.Controls.Add(this.button15);
            this.tabPage3.Controls.Add(this.ButtonClinicSaveData);
            this.tabPage3.Controls.Add(this.groupBox14);
            this.tabPage3.Controls.Add(this.ClinicTabNotesEntry);
            this.tabPage3.Controls.Add(this.groupBox9);
            this.tabPage3.Controls.Add(this.ClinicTabLoadPatient);
            this.tabPage3.Controls.Add(this.label130);
            this.tabPage3.Controls.Add(this.label131);
            this.tabPage3.Controls.Add(this.richTextBox4);
            this.tabPage3.Controls.Add(this.label132);
            this.tabPage3.Controls.Add(this.richTextBox5);
            this.tabPage3.Controls.Add(this.checkBox11);
            this.tabPage3.Controls.Add(this.groupBox15);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(625, 398);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "Clinician";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.button23);
            this.groupBox16.Controls.Add(this.button22);
            this.groupBox16.Controls.Add(this.button21);
            this.groupBox16.Controls.Add(this.textBox56);
            this.groupBox16.Controls.Add(this.textBox50);
            this.groupBox16.Controls.Add(this.textBox49);
            this.groupBox16.Controls.Add(this.textBox48);
            this.groupBox16.Controls.Add(this.textBox47);
            this.groupBox16.Controls.Add(this.label137);
            this.groupBox16.Controls.Add(this.label136);
            this.groupBox16.Controls.Add(this.label135);
            this.groupBox16.Controls.Add(this.label134);
            this.groupBox16.Controls.Add(this.label133);
            this.groupBox16.Controls.Add(this.comboBox29);
            this.groupBox16.Controls.Add(this.comboBox27);
            this.groupBox16.Controls.Add(this.comboBox26);
            this.groupBox16.Controls.Add(this.comboBox25);
            this.groupBox16.Controls.Add(this.comboBox24);
            this.groupBox16.Location = new System.Drawing.Point(6, 85);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(382, 289);
            this.groupBox16.TabIndex = 0;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Plan Of Care";
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(284, 245);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(75, 20);
            this.button23.TabIndex = 1009;
            this.button23.Text = "Scroll Down";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Visible = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(203, 245);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(75, 20);
            this.button22.TabIndex = 1008;
            this.button22.Text = "Scroll Up";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Visible = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(62, 255);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(61, 23);
            this.button21.TabIndex = 1007;
            this.button21.Text = "Add Plan";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // textBox56
            // 
            this.textBox56.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox56.Location = new System.Drawing.Point(28, 223);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(323, 20);
            this.textBox56.TabIndex = 1006;
            this.textBox56.TextChanged += new System.EventHandler(this.textBox56_TextChanged);
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(28, 178);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(323, 20);
            this.textBox50.TabIndex = 1005;
            this.textBox50.TextChanged += new System.EventHandler(this.textBox50_TextChanged);
            // 
            // textBox49
            // 
            this.textBox49.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox49.Location = new System.Drawing.Point(28, 133);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(323, 20);
            this.textBox49.TabIndex = 17;
            this.textBox49.TextChanged += new System.EventHandler(this.textBox49_TextChanged);
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(28, 87);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(323, 20);
            this.textBox48.TabIndex = 16;
            this.textBox48.TextChanged += new System.EventHandler(this.textBox48_TextChanged);
            // 
            // textBox47
            // 
            this.textBox47.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox47.Location = new System.Drawing.Point(28, 40);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(323, 20);
            this.textBox47.TabIndex = 15;
            this.textBox47.TextChanged += new System.EventHandler(this.textBox47_TextChanged);
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(5, 203);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(47, 13);
            this.label137.TabIndex = 14;
            this.label137.Text = "label137";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(7, 158);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(47, 13);
            this.label136.TabIndex = 13;
            this.label136.Text = "label136";
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(7, 112);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(47, 13);
            this.label135.TabIndex = 12;
            this.label135.Text = "label135";
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Location = new System.Drawing.Point(6, 66);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(47, 13);
            this.label134.TabIndex = 11;
            this.label134.Text = "label134";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(6, 19);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(47, 13);
            this.label133.TabIndex = 10;
            this.label133.Text = "label133";
            // 
            // comboBox29
            // 
            this.comboBox29.BackColor = System.Drawing.SystemColors.ControlLight;
            this.comboBox29.FormattingEnabled = true;
            this.comboBox29.Location = new System.Drawing.Point(56, 200);
            this.comboBox29.Name = "comboBox29";
            this.comboBox29.Size = new System.Drawing.Size(303, 21);
            this.comboBox29.TabIndex = 4;
            this.comboBox29.SelectedIndexChanged += new System.EventHandler(this.comboBox29_SelectedIndexChanged);
            this.comboBox29.TextChanged += new System.EventHandler(this.comboBox29_SelectedIndexChanged);
            // 
            // comboBox27
            // 
            this.comboBox27.FormattingEnabled = true;
            this.comboBox27.Location = new System.Drawing.Point(58, 155);
            this.comboBox27.Name = "comboBox27";
            this.comboBox27.Size = new System.Drawing.Size(303, 21);
            this.comboBox27.TabIndex = 3;
            this.comboBox27.SelectedIndexChanged += new System.EventHandler(this.comboBox27_SelectedIndexChanged);
            this.comboBox27.TextChanged += new System.EventHandler(this.comboBox27_SelectedIndexChanged);
            // 
            // comboBox26
            // 
            this.comboBox26.BackColor = System.Drawing.SystemColors.ControlLight;
            this.comboBox26.FormattingEnabled = true;
            this.comboBox26.Location = new System.Drawing.Point(57, 110);
            this.comboBox26.Name = "comboBox26";
            this.comboBox26.Size = new System.Drawing.Size(305, 21);
            this.comboBox26.TabIndex = 2;
            this.comboBox26.SelectedIndexChanged += new System.EventHandler(this.comboBox26_SelectedIndexChanged);
            this.comboBox26.TextChanged += new System.EventHandler(this.comboBox26_SelectedIndexChanged);
            // 
            // comboBox25
            // 
            this.comboBox25.FormattingEnabled = true;
            this.comboBox25.Location = new System.Drawing.Point(56, 63);
            this.comboBox25.Name = "comboBox25";
            this.comboBox25.Size = new System.Drawing.Size(305, 21);
            this.comboBox25.TabIndex = 1;
            this.comboBox25.SelectedIndexChanged += new System.EventHandler(this.comboBox25_SelectedIndexChanged);
            this.comboBox25.TextChanged += new System.EventHandler(this.comboBox25_SelectedIndexChanged);
            // 
            // comboBox24
            // 
            this.comboBox24.BackColor = System.Drawing.SystemColors.ControlLight;
            this.comboBox24.FormattingEnabled = true;
            this.comboBox24.Location = new System.Drawing.Point(56, 16);
            this.comboBox24.Name = "comboBox24";
            this.comboBox24.Size = new System.Drawing.Size(305, 21);
            this.comboBox24.TabIndex = 0;
            this.comboBox24.SelectedIndexChanged += new System.EventHandler(this.comboBox24_SelectedIndexChanged);
            this.comboBox24.TextChanged += new System.EventHandler(this.comboBox24_SelectedIndexChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(19, 88);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(0, 13);
            this.label32.TabIndex = 28;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(308, 375);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 27;
            this.button14.Text = "Plan Of Care";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(397, 99);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(221, 264);
            this.richTextBox3.TabIndex = 11;
            this.richTextBox3.Text = "";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(394, 85);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(38, 13);
            this.label125.TabIndex = 11;
            this.label125.Text = "Notes:";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(394, 295);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(69, 13);
            this.label124.TabIndex = 26;
            this.label124.Text = "Test Results:";
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(253, 226);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(104, 23);
            this.button17.TabIndex = 25;
            this.button17.Text = "Commit Notes";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(394, 88);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(35, 13);
            this.label123.TabIndex = 24;
            this.label123.Text = "Notes";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(394, 350);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(47, 13);
            this.label122.TabIndex = 23;
            this.label122.Text = "label122";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(394, 330);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(47, 13);
            this.label121.TabIndex = 22;
            this.label121.Text = "label121";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(400, 310);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(41, 13);
            this.label76.TabIndex = 21;
            this.label76.Text = "label76";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(397, 104);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(221, 188);
            this.richTextBox2.TabIndex = 19;
            this.richTextBox2.Text = "";
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(7, 375);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(85, 23);
            this.button16.TabIndex = 20;
            this.button16.Text = "Assessments";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(118, 375);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(170, 23);
            this.button15.TabIndex = 11;
            this.button15.Text = "Other Findings and Test Results";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // ButtonClinicSaveData
            // 
            this.ButtonClinicSaveData.Location = new System.Drawing.Point(490, 369);
            this.ButtonClinicSaveData.Name = "ButtonClinicSaveData";
            this.ButtonClinicSaveData.Size = new System.Drawing.Size(109, 23);
            this.ButtonClinicSaveData.TabIndex = 19;
            this.ButtonClinicSaveData.Text = "Save Clinic Data";
            this.ButtonClinicSaveData.UseVisualStyleBackColor = true;
            this.ButtonClinicSaveData.Click += new System.EventHandler(this.ButtonClinicSaveData_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.textBox39);
            this.groupBox14.Controls.Add(this.comboBox23);
            this.groupBox14.Controls.Add(this.label120);
            this.groupBox14.Controls.Add(this.label119);
            this.groupBox14.Controls.Add(this.textBox38);
            this.groupBox14.Controls.Add(this.label118);
            this.groupBox14.Controls.Add(this.comboBox22);
            this.groupBox14.Controls.Add(this.label117);
            this.groupBox14.Location = new System.Drawing.Point(6, 255);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(377, 108);
            this.groupBox14.TabIndex = 17;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Test Results";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(184, 75);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(154, 20);
            this.textBox39.TabIndex = 17;
            this.textBox39.TextChanged += new System.EventHandler(this.textBox39_TextChanged);
            // 
            // comboBox23
            // 
            this.comboBox23.FormattingEnabled = true;
            this.comboBox23.Location = new System.Drawing.Point(90, 75);
            this.comboBox23.Name = "comboBox23";
            this.comboBox23.Size = new System.Drawing.Size(88, 21);
            this.comboBox23.TabIndex = 16;
            this.comboBox23.SelectedIndexChanged += new System.EventHandler(this.comboBox23_SelectedIndexChanged);
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(33, 78);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(58, 13);
            this.label120.TabIndex = 14;
            this.label120.Text = "Stool O&&P:";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(151, 51);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(47, 13);
            this.label119.TabIndex = 13;
            this.label119.Text = "label119";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(91, 48);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(57, 20);
            this.textBox38.TabIndex = 12;
            this.textBox38.TextChanged += new System.EventHandler(this.textBox38_TextChanged);
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(25, 51);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(66, 13);
            this.label118.TabIndex = 11;
            this.label118.Text = "Hemoglobin:";
            // 
            // comboBox22
            // 
            this.comboBox22.FormattingEnabled = true;
            this.comboBox22.Location = new System.Drawing.Point(91, 21);
            this.comboBox22.Name = "comboBox22";
            this.comboBox22.Size = new System.Drawing.Size(92, 21);
            this.comboBox22.TabIndex = 2;
            this.comboBox22.SelectedIndexChanged += new System.EventHandler(this.comboBox22_SelectedIndexChanged);
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(44, 24);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(47, 13);
            this.label117.TabIndex = 1;
            this.label117.Text = "Orasure:";
            // 
            // ClinicTabNotesEntry
            // 
            this.ClinicTabNotesEntry.Location = new System.Drawing.Point(15, 104);
            this.ClinicTabNotesEntry.Name = "ClinicTabNotesEntry";
            this.ClinicTabNotesEntry.Size = new System.Drawing.Size(368, 116);
            this.ClinicTabNotesEntry.TabIndex = 15;
            this.ClinicTabNotesEntry.Text = "";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label52);
            this.groupBox9.Controls.Add(this.label57);
            this.groupBox9.Controls.Add(this.label54);
            this.groupBox9.Controls.Add(this.label56);
            this.groupBox9.Controls.Add(this.label53);
            this.groupBox9.Controls.Add(this.label55);
            this.groupBox9.Location = new System.Drawing.Point(6, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(613, 78);
            this.groupBox9.TabIndex = 14;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Current Patient";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 16);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(41, 13);
            this.label52.TabIndex = 1;
            this.label52.Text = "label52";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(336, 60);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(41, 13);
            this.label57.TabIndex = 13;
            this.label57.Text = "label57";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(6, 60);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(41, 13);
            this.label54.TabIndex = 10;
            this.label54.Text = "label54";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(336, 38);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(41, 13);
            this.label56.TabIndex = 12;
            this.label56.Text = "label56";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(6, 38);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(41, 13);
            this.label53.TabIndex = 9;
            this.label53.Text = "label53";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(336, 16);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(41, 13);
            this.label55.TabIndex = 11;
            this.label55.Text = "label55";
            // 
            // ClinicTabLoadPatient
            // 
            this.ClinicTabLoadPatient.Location = new System.Drawing.Point(397, 369);
            this.ClinicTabLoadPatient.Name = "ClinicTabLoadPatient";
            this.ClinicTabLoadPatient.Size = new System.Drawing.Size(75, 23);
            this.ClinicTabLoadPatient.TabIndex = 0;
            this.ClinicTabLoadPatient.Text = "Load Patient";
            this.ClinicTabLoadPatient.UseVisualStyleBackColor = true;
            this.ClinicTabLoadPatient.Click += new System.EventHandler(this.ClinicTabLoadPatient_Click);
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Location = new System.Drawing.Point(18, 87);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(78, 13);
            this.label130.TabIndex = 29;
            this.label130.Text = "Other Findings:";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Location = new System.Drawing.Point(394, 87);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(38, 13);
            this.label131.TabIndex = 30;
            this.label131.Text = "Notes:";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(397, 99);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(221, 122);
            this.richTextBox4.TabIndex = 31;
            this.richTextBox4.Text = "";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Location = new System.Drawing.Point(398, 221);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(71, 13);
            this.label132.TabIndex = 1004;
            this.label132.Text = "Assessments:";
            // 
            // richTextBox5
            // 
            this.richTextBox5.Location = new System.Drawing.Point(397, 237);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(221, 132);
            this.richTextBox5.TabIndex = 1003;
            this.richTextBox5.Text = "";
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(490, 220);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(131, 17);
            this.checkBox11.TabIndex = 1003;
            this.checkBox11.Text = "Show All Assessments";
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.textBox55);
            this.groupBox15.Controls.Add(this.textBox54);
            this.groupBox15.Controls.Add(this.textBox53);
            this.groupBox15.Controls.Add(this.textBox52);
            this.groupBox15.Controls.Add(this.textBox51);
            this.groupBox15.Controls.Add(this.checkBox10);
            this.groupBox15.Controls.Add(this.checkBox9);
            this.groupBox15.Controls.Add(this.checkBox8);
            this.groupBox15.Controls.Add(this.checkBox7);
            this.groupBox15.Controls.Add(this.checkBox6);
            this.groupBox15.Controls.Add(this.textBox46);
            this.groupBox15.Controls.Add(this.textBox45);
            this.groupBox15.Controls.Add(this.textBox44);
            this.groupBox15.Controls.Add(this.textBox43);
            this.groupBox15.Controls.Add(this.textBox42);
            this.groupBox15.Controls.Add(this.button20);
            this.groupBox15.Controls.Add(this.button19);
            this.groupBox15.Controls.Add(this.button18);
            this.groupBox15.Controls.Add(this.button13);
            this.groupBox15.Controls.Add(this.textBox41);
            this.groupBox15.Controls.Add(this.label129);
            this.groupBox15.Controls.Add(this.textBox40);
            this.groupBox15.Controls.Add(this.label126);
            this.groupBox15.Location = new System.Drawing.Point(6, 85);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(381, 289);
            this.groupBox15.TabIndex = 11;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Assessments";
            // 
            // textBox55
            // 
            this.textBox55.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox55.Location = new System.Drawing.Point(48, 191);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(303, 20);
            this.textBox55.TabIndex = 52;
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(48, 147);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(303, 20);
            this.textBox54.TabIndex = 51;
            // 
            // textBox53
            // 
            this.textBox53.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox53.Location = new System.Drawing.Point(48, 103);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(304, 20);
            this.textBox53.TabIndex = 50;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(48, 59);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(304, 20);
            this.textBox52.TabIndex = 49;
            // 
            // textBox51
            // 
            this.textBox51.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox51.Location = new System.Drawing.Point(47, 14);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(304, 20);
            this.textBox51.TabIndex = 48;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(7, 194);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(15, 14);
            this.checkBox10.TabIndex = 40;
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(6, 149);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(15, 14);
            this.checkBox9.TabIndex = 39;
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(6, 105);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(15, 14);
            this.checkBox8.TabIndex = 38;
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(7, 61);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 37;
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(6, 16);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 36;
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // textBox46
            // 
            this.textBox46.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox46.Location = new System.Drawing.Point(19, 213);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(357, 20);
            this.textBox46.TabIndex = 31;
            this.textBox46.TextChanged += new System.EventHandler(this.textBox46_TextChanged);
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(19, 168);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(357, 20);
            this.textBox45.TabIndex = 30;
            this.textBox45.TextChanged += new System.EventHandler(this.textBox45_TextChanged);
            // 
            // textBox44
            // 
            this.textBox44.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox44.Location = new System.Drawing.Point(20, 124);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(356, 20);
            this.textBox44.TabIndex = 29;
            this.textBox44.TextChanged += new System.EventHandler(this.textBox44_TextChanged);
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(20, 80);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(356, 20);
            this.textBox43.TabIndex = 28;
            this.textBox43.TextChanged += new System.EventHandler(this.textBox43_TextChanged);
            // 
            // textBox42
            // 
            this.textBox42.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox42.Location = new System.Drawing.Point(19, 35);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(356, 20);
            this.textBox42.TabIndex = 27;
            this.textBox42.TextChanged += new System.EventHandler(this.textBox42_TextChanged);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(227, 234);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(75, 20);
            this.button20.TabIndex = 12;
            this.button20.Text = "scroll up";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Visible = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(304, 234);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(75, 20);
            this.button19.TabIndex = 11;
            this.button19.Text = "scroll down";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Visible = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(120, 238);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(102, 23);
            this.button18.TabIndex = 5;
            this.button18.Text = "Remove Selected";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(5, 238);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(109, 23);
            this.button13.TabIndex = 4;
            this.button13.Text = "Add Assessment";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(181, 265);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(194, 20);
            this.textBox41.TabIndex = 3;
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Location = new System.Drawing.Point(151, 268);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(33, 13);
            this.label129.TabIndex = 2;
            this.label129.Text = "Note:";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(53, 265);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(92, 20);
            this.textBox40.TabIndex = 1;
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(2, 268);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(54, 13);
            this.label126.TabIndex = 0;
            this.label126.Text = "Condition:";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Bisque;
            this.tabPage4.Controls.Add(this.checkBox25);
            this.tabPage4.Controls.Add(this.textBox108);
            this.tabPage4.Controls.Add(this.textBox107);
            this.tabPage4.Controls.Add(this.textBox106);
            this.tabPage4.Controls.Add(this.textBox105);
            this.tabPage4.Controls.Add(this.textBox104);
            this.tabPage4.Controls.Add(this.textBox103);
            this.tabPage4.Controls.Add(this.textBox102);
            this.tabPage4.Controls.Add(this.textBox101);
            this.tabPage4.Controls.Add(this.textBox100);
            this.tabPage4.Controls.Add(this.textBox99);
            this.tabPage4.Controls.Add(this.textBox98);
            this.tabPage4.Controls.Add(this.textBox97);
            this.tabPage4.Controls.Add(this.textBox96);
            this.tabPage4.Controls.Add(this.button28);
            this.tabPage4.Controls.Add(this.button27);
            this.tabPage4.Controls.Add(this.button26);
            this.tabPage4.Controls.Add(this.button25);
            this.tabPage4.Controls.Add(this.textBox95);
            this.tabPage4.Controls.Add(this.textBox94);
            this.tabPage4.Controls.Add(this.textBox93);
            this.tabPage4.Controls.Add(this.textBox92);
            this.tabPage4.Controls.Add(this.textBox91);
            this.tabPage4.Controls.Add(this.textBox90);
            this.tabPage4.Controls.Add(this.textBox89);
            this.tabPage4.Controls.Add(this.textBox88);
            this.tabPage4.Controls.Add(this.textBox87);
            this.tabPage4.Controls.Add(this.textBox86);
            this.tabPage4.Controls.Add(this.textBox85);
            this.tabPage4.Controls.Add(this.textBox84);
            this.tabPage4.Controls.Add(this.textBox83);
            this.tabPage4.Controls.Add(this.label147);
            this.tabPage4.Controls.Add(this.label146);
            this.tabPage4.Controls.Add(this.label145);
            this.tabPage4.Controls.Add(this.checkBox24);
            this.tabPage4.Controls.Add(this.checkBox23);
            this.tabPage4.Controls.Add(this.checkBox22);
            this.tabPage4.Controls.Add(this.checkBox21);
            this.tabPage4.Controls.Add(this.checkBox20);
            this.tabPage4.Controls.Add(this.checkBox19);
            this.tabPage4.Controls.Add(this.checkBox18);
            this.tabPage4.Controls.Add(this.checkBox17);
            this.tabPage4.Controls.Add(this.checkBox16);
            this.tabPage4.Controls.Add(this.checkBox15);
            this.tabPage4.Controls.Add(this.checkBox14);
            this.tabPage4.Controls.Add(this.checkBox13);
            this.tabPage4.Controls.Add(this.checkBox12);
            this.tabPage4.Controls.Add(this.textBox82);
            this.tabPage4.Controls.Add(this.textBox81);
            this.tabPage4.Controls.Add(this.textBox80);
            this.tabPage4.Controls.Add(this.textBox79);
            this.tabPage4.Controls.Add(this.textBox78);
            this.tabPage4.Controls.Add(this.textBox77);
            this.tabPage4.Controls.Add(this.textBox76);
            this.tabPage4.Controls.Add(this.textBox75);
            this.tabPage4.Controls.Add(this.textBox74);
            this.tabPage4.Controls.Add(this.textBox73);
            this.tabPage4.Controls.Add(this.textBox61);
            this.tabPage4.Controls.Add(this.textBox60);
            this.tabPage4.Controls.Add(this.textBox59);
            this.tabPage4.Controls.Add(this.label144);
            this.tabPage4.Controls.Add(this.textBox72);
            this.tabPage4.Controls.Add(this.textBox71);
            this.tabPage4.Controls.Add(this.textBox70);
            this.tabPage4.Controls.Add(this.textBox69);
            this.tabPage4.Controls.Add(this.textBox68);
            this.tabPage4.Controls.Add(this.textBox67);
            this.tabPage4.Controls.Add(this.textBox66);
            this.tabPage4.Controls.Add(this.textBox65);
            this.tabPage4.Controls.Add(this.textBox64);
            this.tabPage4.Controls.Add(this.textBox63);
            this.tabPage4.Controls.Add(this.textBox62);
            this.tabPage4.Controls.Add(this.textBox58);
            this.tabPage4.Controls.Add(this.textBox57);
            this.tabPage4.Controls.Add(this.button24);
            this.tabPage4.Controls.Add(this.groupBox17);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(625, 398);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Lab/Pharmacy";
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Location = new System.Drawing.Point(413, 375);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(102, 17);
            this.checkBox25.TabIndex = 93;
            this.checkBox25.Text = "Show Removed";
            this.checkBox25.UseVisualStyleBackColor = true;
            this.checkBox25.CheckedChanged += new System.EventHandler(this.checkBox25_CheckedChanged);
            // 
            // textBox108
            // 
            this.textBox108.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox108.Location = new System.Drawing.Point(6, 349);
            this.textBox108.Name = "textBox108";
            this.textBox108.ReadOnly = true;
            this.textBox108.Size = new System.Drawing.Size(22, 20);
            this.textBox108.TabIndex = 92;
            // 
            // textBox107
            // 
            this.textBox107.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox107.Location = new System.Drawing.Point(6, 328);
            this.textBox107.Name = "textBox107";
            this.textBox107.ReadOnly = true;
            this.textBox107.Size = new System.Drawing.Size(22, 20);
            this.textBox107.TabIndex = 91;
            // 
            // textBox106
            // 
            this.textBox106.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox106.Location = new System.Drawing.Point(6, 307);
            this.textBox106.Name = "textBox106";
            this.textBox106.ReadOnly = true;
            this.textBox106.Size = new System.Drawing.Size(22, 20);
            this.textBox106.TabIndex = 90;
            // 
            // textBox105
            // 
            this.textBox105.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox105.Location = new System.Drawing.Point(6, 286);
            this.textBox105.Name = "textBox105";
            this.textBox105.ReadOnly = true;
            this.textBox105.Size = new System.Drawing.Size(22, 20);
            this.textBox105.TabIndex = 89;
            // 
            // textBox104
            // 
            this.textBox104.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox104.Location = new System.Drawing.Point(6, 265);
            this.textBox104.Name = "textBox104";
            this.textBox104.ReadOnly = true;
            this.textBox104.Size = new System.Drawing.Size(22, 20);
            this.textBox104.TabIndex = 88;
            // 
            // textBox103
            // 
            this.textBox103.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox103.Location = new System.Drawing.Point(6, 244);
            this.textBox103.Name = "textBox103";
            this.textBox103.ReadOnly = true;
            this.textBox103.Size = new System.Drawing.Size(22, 20);
            this.textBox103.TabIndex = 87;
            // 
            // textBox102
            // 
            this.textBox102.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox102.Location = new System.Drawing.Point(6, 223);
            this.textBox102.Name = "textBox102";
            this.textBox102.ReadOnly = true;
            this.textBox102.Size = new System.Drawing.Size(22, 20);
            this.textBox102.TabIndex = 86;
            // 
            // textBox101
            // 
            this.textBox101.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox101.Location = new System.Drawing.Point(6, 202);
            this.textBox101.Name = "textBox101";
            this.textBox101.ReadOnly = true;
            this.textBox101.Size = new System.Drawing.Size(22, 20);
            this.textBox101.TabIndex = 85;
            // 
            // textBox100
            // 
            this.textBox100.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox100.Location = new System.Drawing.Point(6, 181);
            this.textBox100.Name = "textBox100";
            this.textBox100.ReadOnly = true;
            this.textBox100.Size = new System.Drawing.Size(22, 20);
            this.textBox100.TabIndex = 84;
            // 
            // textBox99
            // 
            this.textBox99.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox99.Location = new System.Drawing.Point(6, 160);
            this.textBox99.Name = "textBox99";
            this.textBox99.ReadOnly = true;
            this.textBox99.Size = new System.Drawing.Size(22, 20);
            this.textBox99.TabIndex = 83;
            // 
            // textBox98
            // 
            this.textBox98.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox98.Location = new System.Drawing.Point(6, 139);
            this.textBox98.Name = "textBox98";
            this.textBox98.ReadOnly = true;
            this.textBox98.Size = new System.Drawing.Size(22, 20);
            this.textBox98.TabIndex = 82;
            // 
            // textBox97
            // 
            this.textBox97.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox97.Location = new System.Drawing.Point(6, 118);
            this.textBox97.Name = "textBox97";
            this.textBox97.ReadOnly = true;
            this.textBox97.Size = new System.Drawing.Size(22, 20);
            this.textBox97.TabIndex = 81;
            // 
            // textBox96
            // 
            this.textBox96.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox96.Location = new System.Drawing.Point(6, 97);
            this.textBox96.Name = "textBox96";
            this.textBox96.ReadOnly = true;
            this.textBox96.Size = new System.Drawing.Size(22, 20);
            this.textBox96.TabIndex = 80;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(87, 369);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(75, 22);
            this.button28.TabIndex = 79;
            this.button28.Text = "Scroll Down";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Visible = false;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(6, 369);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(75, 22);
            this.button27.TabIndex = 78;
            this.button27.Text = "Scroll Up";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Visible = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(283, 372);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(86, 23);
            this.button26.TabIndex = 77;
            this.button26.Text = "Store Patient";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(521, 372);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(101, 23);
            this.button25.TabIndex = 76;
            this.button25.Text = "Remove Selected";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // textBox95
            // 
            this.textBox95.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox95.Location = new System.Drawing.Point(27, 349);
            this.textBox95.Name = "textBox95";
            this.textBox95.ReadOnly = true;
            this.textBox95.Size = new System.Drawing.Size(330, 20);
            this.textBox95.TabIndex = 75;
            // 
            // textBox94
            // 
            this.textBox94.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox94.Location = new System.Drawing.Point(27, 328);
            this.textBox94.Name = "textBox94";
            this.textBox94.ReadOnly = true;
            this.textBox94.Size = new System.Drawing.Size(330, 20);
            this.textBox94.TabIndex = 74;
            // 
            // textBox93
            // 
            this.textBox93.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox93.Location = new System.Drawing.Point(27, 307);
            this.textBox93.Name = "textBox93";
            this.textBox93.ReadOnly = true;
            this.textBox93.Size = new System.Drawing.Size(330, 20);
            this.textBox93.TabIndex = 73;
            // 
            // textBox92
            // 
            this.textBox92.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox92.Location = new System.Drawing.Point(27, 286);
            this.textBox92.Name = "textBox92";
            this.textBox92.ReadOnly = true;
            this.textBox92.Size = new System.Drawing.Size(330, 20);
            this.textBox92.TabIndex = 72;
            // 
            // textBox91
            // 
            this.textBox91.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox91.Location = new System.Drawing.Point(27, 265);
            this.textBox91.Name = "textBox91";
            this.textBox91.ReadOnly = true;
            this.textBox91.Size = new System.Drawing.Size(330, 20);
            this.textBox91.TabIndex = 71;
            // 
            // textBox90
            // 
            this.textBox90.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox90.Location = new System.Drawing.Point(27, 244);
            this.textBox90.Name = "textBox90";
            this.textBox90.ReadOnly = true;
            this.textBox90.Size = new System.Drawing.Size(330, 20);
            this.textBox90.TabIndex = 70;
            // 
            // textBox89
            // 
            this.textBox89.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox89.Location = new System.Drawing.Point(27, 223);
            this.textBox89.Name = "textBox89";
            this.textBox89.ReadOnly = true;
            this.textBox89.Size = new System.Drawing.Size(330, 20);
            this.textBox89.TabIndex = 69;
            // 
            // textBox88
            // 
            this.textBox88.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox88.Location = new System.Drawing.Point(27, 202);
            this.textBox88.Name = "textBox88";
            this.textBox88.ReadOnly = true;
            this.textBox88.Size = new System.Drawing.Size(330, 20);
            this.textBox88.TabIndex = 68;
            // 
            // textBox87
            // 
            this.textBox87.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox87.Location = new System.Drawing.Point(27, 181);
            this.textBox87.Name = "textBox87";
            this.textBox87.ReadOnly = true;
            this.textBox87.Size = new System.Drawing.Size(330, 20);
            this.textBox87.TabIndex = 67;
            // 
            // textBox86
            // 
            this.textBox86.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox86.Location = new System.Drawing.Point(27, 160);
            this.textBox86.Name = "textBox86";
            this.textBox86.ReadOnly = true;
            this.textBox86.Size = new System.Drawing.Size(330, 20);
            this.textBox86.TabIndex = 66;
            // 
            // textBox85
            // 
            this.textBox85.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox85.Location = new System.Drawing.Point(27, 139);
            this.textBox85.Name = "textBox85";
            this.textBox85.ReadOnly = true;
            this.textBox85.Size = new System.Drawing.Size(330, 20);
            this.textBox85.TabIndex = 65;
            // 
            // textBox84
            // 
            this.textBox84.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox84.Location = new System.Drawing.Point(27, 118);
            this.textBox84.Name = "textBox84";
            this.textBox84.ReadOnly = true;
            this.textBox84.Size = new System.Drawing.Size(330, 20);
            this.textBox84.TabIndex = 64;
            // 
            // textBox83
            // 
            this.textBox83.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox83.Location = new System.Drawing.Point(27, 97);
            this.textBox83.Name = "textBox83";
            this.textBox83.ReadOnly = true;
            this.textBox83.Size = new System.Drawing.Size(330, 20);
            this.textBox83.TabIndex = 63;
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.Location = new System.Drawing.Point(31, 84);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(36, 13);
            this.label147.TabIndex = 62;
            this.label147.Text = "Order:";
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.Location = new System.Drawing.Point(578, 84);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(50, 13);
            this.label146.TabIndex = 61;
            this.label146.Text = "Remove:";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.Location = new System.Drawing.Point(430, 84);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(54, 13);
            this.label145.TabIndex = 60;
            this.label145.Text = "Comment:";
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Location = new System.Drawing.Point(604, 352);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(15, 14);
            this.checkBox24.TabIndex = 59;
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Location = new System.Drawing.Point(604, 331);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(15, 14);
            this.checkBox23.TabIndex = 58;
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Location = new System.Drawing.Point(604, 310);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(15, 14);
            this.checkBox22.TabIndex = 57;
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Location = new System.Drawing.Point(604, 289);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(15, 14);
            this.checkBox21.TabIndex = 56;
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(604, 268);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(15, 14);
            this.checkBox20.TabIndex = 55;
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Location = new System.Drawing.Point(604, 247);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(15, 14);
            this.checkBox19.TabIndex = 54;
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(604, 226);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(15, 14);
            this.checkBox18.TabIndex = 53;
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(604, 205);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(15, 14);
            this.checkBox17.TabIndex = 52;
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(604, 184);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(15, 14);
            this.checkBox16.TabIndex = 51;
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(604, 163);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(15, 14);
            this.checkBox15.TabIndex = 50;
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(603, 142);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(15, 14);
            this.checkBox14.TabIndex = 49;
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(603, 121);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(15, 14);
            this.checkBox13.TabIndex = 48;
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(603, 100);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(15, 14);
            this.checkBox12.TabIndex = 47;
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // textBox82
            // 
            this.textBox82.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox82.Location = new System.Drawing.Point(407, 349);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(192, 20);
            this.textBox82.TabIndex = 46;
            this.textBox82.TextChanged += new System.EventHandler(this.textBox82_TextChanged);
            // 
            // textBox81
            // 
            this.textBox81.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox81.Location = new System.Drawing.Point(407, 328);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(192, 20);
            this.textBox81.TabIndex = 45;
            this.textBox81.TextChanged += new System.EventHandler(this.textBox81_TextChanged);
            // 
            // textBox80
            // 
            this.textBox80.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox80.Location = new System.Drawing.Point(407, 307);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(192, 20);
            this.textBox80.TabIndex = 44;
            this.textBox80.TextChanged += new System.EventHandler(this.textBox80_TextChanged);
            // 
            // textBox79
            // 
            this.textBox79.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox79.Location = new System.Drawing.Point(407, 286);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(192, 20);
            this.textBox79.TabIndex = 43;
            this.textBox79.TextChanged += new System.EventHandler(this.textBox79_TextChanged);
            // 
            // textBox78
            // 
            this.textBox78.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox78.Location = new System.Drawing.Point(407, 265);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(192, 20);
            this.textBox78.TabIndex = 42;
            this.textBox78.TextChanged += new System.EventHandler(this.textBox78_TextChanged);
            // 
            // textBox77
            // 
            this.textBox77.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox77.Location = new System.Drawing.Point(407, 244);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(192, 20);
            this.textBox77.TabIndex = 41;
            this.textBox77.TextChanged += new System.EventHandler(this.textBox77_TextChanged);
            // 
            // textBox76
            // 
            this.textBox76.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox76.Location = new System.Drawing.Point(407, 223);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(192, 20);
            this.textBox76.TabIndex = 40;
            this.textBox76.TextChanged += new System.EventHandler(this.textBox76_TextChanged);
            // 
            // textBox75
            // 
            this.textBox75.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox75.Location = new System.Drawing.Point(407, 202);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(192, 20);
            this.textBox75.TabIndex = 39;
            this.textBox75.TextChanged += new System.EventHandler(this.textBox75_TextChanged);
            // 
            // textBox74
            // 
            this.textBox74.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox74.Location = new System.Drawing.Point(407, 181);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(192, 20);
            this.textBox74.TabIndex = 38;
            this.textBox74.TextChanged += new System.EventHandler(this.textBox74_TextChanged);
            // 
            // textBox73
            // 
            this.textBox73.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox73.Location = new System.Drawing.Point(407, 160);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(192, 20);
            this.textBox73.TabIndex = 37;
            this.textBox73.TextChanged += new System.EventHandler(this.textBox73_TextChanged);
            // 
            // textBox61
            // 
            this.textBox61.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox61.Location = new System.Drawing.Point(407, 139);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(192, 20);
            this.textBox61.TabIndex = 36;
            this.textBox61.TextChanged += new System.EventHandler(this.textBox61_TextChanged);
            // 
            // textBox60
            // 
            this.textBox60.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox60.Location = new System.Drawing.Point(407, 118);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(192, 20);
            this.textBox60.TabIndex = 35;
            this.textBox60.TextChanged += new System.EventHandler(this.textBox60_TextChanged);
            // 
            // textBox59
            // 
            this.textBox59.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox59.Location = new System.Drawing.Point(407, 97);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(192, 20);
            this.textBox59.TabIndex = 34;
            this.textBox59.TextChanged += new System.EventHandler(this.textBox59_TextChanged);
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Location = new System.Drawing.Point(359, 84);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(48, 13);
            this.label144.TabIndex = 33;
            this.label144.Text = "#/action";
            // 
            // textBox72
            // 
            this.textBox72.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox72.Location = new System.Drawing.Point(357, 328);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(50, 20);
            this.textBox72.TabIndex = 32;
            this.textBox72.TextChanged += new System.EventHandler(this.textBox72_TextChanged);
            // 
            // textBox71
            // 
            this.textBox71.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox71.Location = new System.Drawing.Point(357, 307);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(50, 20);
            this.textBox71.TabIndex = 31;
            this.textBox71.TextChanged += new System.EventHandler(this.textBox71_TextChanged);
            // 
            // textBox70
            // 
            this.textBox70.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox70.Location = new System.Drawing.Point(357, 286);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(50, 20);
            this.textBox70.TabIndex = 30;
            this.textBox70.TextChanged += new System.EventHandler(this.textBox70_TextChanged);
            // 
            // textBox69
            // 
            this.textBox69.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox69.Location = new System.Drawing.Point(357, 265);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(50, 20);
            this.textBox69.TabIndex = 29;
            this.textBox69.TextChanged += new System.EventHandler(this.textBox69_TextChanged);
            // 
            // textBox68
            // 
            this.textBox68.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox68.Location = new System.Drawing.Point(357, 244);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(50, 20);
            this.textBox68.TabIndex = 28;
            this.textBox68.TextChanged += new System.EventHandler(this.textBox68_TextChanged);
            // 
            // textBox67
            // 
            this.textBox67.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox67.Location = new System.Drawing.Point(357, 223);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(50, 20);
            this.textBox67.TabIndex = 27;
            this.textBox67.TextChanged += new System.EventHandler(this.textBox67_TextChanged);
            // 
            // textBox66
            // 
            this.textBox66.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox66.Location = new System.Drawing.Point(357, 202);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(50, 20);
            this.textBox66.TabIndex = 26;
            this.textBox66.TextChanged += new System.EventHandler(this.textBox66_TextChanged);
            // 
            // textBox65
            // 
            this.textBox65.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox65.Location = new System.Drawing.Point(357, 181);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(50, 20);
            this.textBox65.TabIndex = 25;
            this.textBox65.TextChanged += new System.EventHandler(this.textBox65_TextChanged);
            // 
            // textBox64
            // 
            this.textBox64.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox64.Location = new System.Drawing.Point(357, 160);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(50, 20);
            this.textBox64.TabIndex = 24;
            this.textBox64.TextChanged += new System.EventHandler(this.textBox64_TextChanged);
            // 
            // textBox63
            // 
            this.textBox63.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox63.Location = new System.Drawing.Point(357, 139);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(50, 20);
            this.textBox63.TabIndex = 23;
            this.textBox63.TextChanged += new System.EventHandler(this.textBox63_TextChanged);
            // 
            // textBox62
            // 
            this.textBox62.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBox62.Location = new System.Drawing.Point(357, 118);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(50, 20);
            this.textBox62.TabIndex = 22;
            this.textBox62.TextChanged += new System.EventHandler(this.textBox62_TextChanged);
            // 
            // textBox58
            // 
            this.textBox58.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox58.Location = new System.Drawing.Point(357, 349);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(50, 20);
            this.textBox58.TabIndex = 18;
            this.textBox58.TextChanged += new System.EventHandler(this.textBox58_TextChanged);
            // 
            // textBox57
            // 
            this.textBox57.BackColor = System.Drawing.SystemColors.ControlLight;
            this.textBox57.Location = new System.Drawing.Point(357, 97);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(50, 20);
            this.textBox57.TabIndex = 17;
            this.textBox57.TextChanged += new System.EventHandler(this.textBox57_TextChanged);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(202, 372);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(75, 23);
            this.button24.TabIndex = 16;
            this.button24.Text = "Load Patient";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.label138);
            this.groupBox17.Controls.Add(this.label139);
            this.groupBox17.Controls.Add(this.label140);
            this.groupBox17.Controls.Add(this.label141);
            this.groupBox17.Controls.Add(this.label142);
            this.groupBox17.Controls.Add(this.label143);
            this.groupBox17.Location = new System.Drawing.Point(6, 3);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(613, 78);
            this.groupBox17.TabIndex = 15;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Current Patient";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(6, 16);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(47, 13);
            this.label138.TabIndex = 1;
            this.label138.Text = "label138";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(336, 60);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(47, 13);
            this.label139.TabIndex = 13;
            this.label139.Text = "label139";
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(6, 60);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(47, 13);
            this.label140.TabIndex = 10;
            this.label140.Text = "label140";
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(336, 38);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(47, 13);
            this.label141.TabIndex = 12;
            this.label141.Text = "label141";
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(6, 38);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(47, 13);
            this.label142.TabIndex = 9;
            this.label142.Text = "label142";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Location = new System.Drawing.Point(336, 16);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(47, 13);
            this.label143.TabIndex = 11;
            this.label143.Text = "label143";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.LightYellow;
            this.tabPage5.Controls.Add(this.button29);
            this.tabPage5.Controls.Add(this.ExitButton);
            this.tabPage5.Controls.Add(this.richTextBox1);
            this.tabPage5.Controls.Add(this.label31);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(625, 398);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "Exit";
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(198, 306);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(202, 23);
            this.button29.TabIndex = 2;
            this.button29.Text = "Load Patient For Review";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // ExitButton
            // 
            this.ExitButton.Location = new System.Drawing.Point(14, 336);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(579, 56);
            this.ExitButton.TabIndex = 1;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click_1);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.LightYellow;
            this.richTextBox1.Location = new System.Drawing.Point(14, 27);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(579, 273);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = "";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(11, 11);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(101, 13);
            this.label31.TabIndex = 0;
            this.label31.Text = "Review Information:";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.button3);
            this.tabPage6.Controls.Add(this.button2);
            this.tabPage6.Controls.Add(this.groupBox3);
            this.tabPage6.Controls.Add(this.comboBoxScribeList);
            this.tabPage6.Controls.Add(this.groupBox1);
            this.tabPage6.Controls.Add(this.label60);
            this.tabPage6.Controls.Add(this.textBox1);
            this.tabPage6.Controls.Add(this.label3);
            this.tabPage6.Controls.Add(this.label4);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Controls.Add(this.ListBoxPathType);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(625, 398);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Admin";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(5, 223);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(101, 13);
            this.label18.TabIndex = 1013;
            this.label18.Text = "Hemoglobin Range:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(4, 197);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 13);
            this.label17.TabIndex = 1012;
            this.label17.Text = "Max Year in School:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 171);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 13);
            this.label16.TabIndex = 1011;
            this.label16.Text = "Min Year In School:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(45, 145);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 13);
            this.label15.TabIndex = 1010;
            this.label15.Text = "Time Zone:";
            // 
            // comboBoxScribeList
            // 
            this.comboBoxScribeList.FormattingEnabled = true;
            this.comboBoxScribeList.Location = new System.Drawing.Point(321, 39);
            this.comboBoxScribeList.Name = "comboBoxScribeList";
            this.comboBoxScribeList.Size = new System.Drawing.Size(100, 21);
            this.comboBoxScribeList.TabIndex = 10;
            this.comboBoxScribeList.TabStop = false;
            this.comboBoxScribeList.SelectedIndexChanged += new System.EventHandler(this.comboBoxScribeList_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.textBox15);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.textBox14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.textBox13);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.textBox12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Location = new System.Drawing.Point(7, 16);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(218, 376);
            this.groupBox1.TabIndex = 1003;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Clinic Data";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(112, 350);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 20);
            this.textBox15.TabIndex = 1013;
            this.textBox15.TextChanged += new System.EventHandler(this.textBox15_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(51, 119);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "End Date:";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(112, 324);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 20);
            this.textBox14.TabIndex = 1012;
            this.textBox14.TextChanged += new System.EventHandler(this.textBox14_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(48, 93);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Start Date:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 353);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 13);
            this.label14.TabIndex = 1009;
            this.label14.Text = "Author Last Name:";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(112, 298);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 20);
            this.textBox13.TabIndex = 1011;
            this.textBox13.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 327);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(94, 13);
            this.label13.TabIndex = 1008;
            this.label13.Text = "Author First Name:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Clinic GPS:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(36, 301);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 13);
            this.label12.TabIndex = 1007;
            this.label12.Text = "Author Prefix:";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(112, 272);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 1010;
            this.textBox12.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(35, 275);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 13);
            this.label11.TabIndex = 1006;
            this.label11.Text = "Custodian ID:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Clinic Details:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 249);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(88, 13);
            this.label10.TabIndex = 1005;
            this.label10.Text = "Custodian Name:";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(112, 246);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 20);
            this.textBox11.TabIndex = 1009;
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Clinic Name:";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(112, 220);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 20);
            this.textBox10.TabIndex = 1008;
            this.textBox10.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(112, 116);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 4;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(112, 194);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 20);
            this.textBox9.TabIndex = 1007;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(112, 90);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 3;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(112, 168);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 20);
            this.textBox8.TabIndex = 1006;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(112, 64);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 2;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(112, 142);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 1005;
            this.textBox7.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(112, 38);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 1;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(112, 12);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 0;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(275, 42);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(40, 13);
            this.label60.TabIndex = 1002;
            this.label60.Text = "Scribe:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(321, 13);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 1004;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(241, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 13);
            this.label3.TabIndex = 1003;
            this.label3.Text = "Station Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(554, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Version #: 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(427, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Select System Type";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.textBox110);
            this.groupBox2.Controls.Add(this.textBox109);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.listBox1);
            this.groupBox2.Location = new System.Drawing.Point(77, 46);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(194, 171);
            this.groupBox2.TabIndex = 1005;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Languages";
            this.groupBox2.Visible = false;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(3, 16);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(187, 43);
            this.listBox1.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(23, 68);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Name:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(26, 91);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 13);
            this.label20.TabIndex = 2;
            this.label20.Text = "Code:";
            // 
            // textBox109
            // 
            this.textBox109.Location = new System.Drawing.Point(64, 65);
            this.textBox109.Name = "textBox109";
            this.textBox109.Size = new System.Drawing.Size(100, 20);
            this.textBox109.TabIndex = 3;
            // 
            // textBox110
            // 
            this.textBox110.Location = new System.Drawing.Point(64, 88);
            this.textBox110.Name = "textBox110";
            this.textBox110.Size = new System.Drawing.Size(100, 20);
            this.textBox110.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(26, 113);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Add Language:";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox18);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.comboBox2);
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Location = new System.Drawing.Point(231, 93);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(358, 263);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Manage Lists";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(77, 17);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 21);
            this.comboBox2.TabIndex = 1005;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(15, 20);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 13);
            this.label21.TabIndex = 1006;
            this.label21.Text = "Select List:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(356, 369);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(114, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Load Clinic Settings";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(487, 369);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(114, 23);
            this.button3.TabIndex = 1005;
            this.button3.Text = "Store Clinic Settings";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox113);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.button4);
            this.groupBox4.Controls.Add(this.textBox111);
            this.groupBox4.Controls.Add(this.textBox112);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.listBox2);
            this.groupBox4.Location = new System.Drawing.Point(77, 50);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(194, 167);
            this.groupBox4.TabIndex = 1006;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Medications";
            this.groupBox4.Visible = false;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(26, 137);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(138, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "Add Medication";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox111
            // 
            this.textBox111.Location = new System.Drawing.Point(88, 88);
            this.textBox111.Name = "textBox111";
            this.textBox111.Size = new System.Drawing.Size(100, 20);
            this.textBox111.TabIndex = 4;
            // 
            // textBox112
            // 
            this.textBox112.Location = new System.Drawing.Point(88, 65);
            this.textBox112.Name = "textBox112";
            this.textBox112.Size = new System.Drawing.Size(100, 20);
            this.textBox112.TabIndex = 3;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(50, 91);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 13);
            this.label22.TabIndex = 2;
            this.label22.Text = "Code:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 68);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(75, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "Display Name:";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(3, 16);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(187, 43);
            this.listBox2.TabIndex = 0;
            // 
            // textBox113
            // 
            this.textBox113.Location = new System.Drawing.Point(88, 113);
            this.textBox113.Name = "textBox113";
            this.textBox113.Size = new System.Drawing.Size(100, 20);
            this.textBox113.TabIndex = 7;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(54, 116);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(31, 13);
            this.label24.TabIndex = 6;
            this.label24.Text = "Text:";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.textBox114);
            this.groupBox18.Controls.Add(this.label25);
            this.groupBox18.Controls.Add(this.button5);
            this.groupBox18.Controls.Add(this.textBox115);
            this.groupBox18.Controls.Add(this.textBox116);
            this.groupBox18.Controls.Add(this.label26);
            this.groupBox18.Controls.Add(this.label27);
            this.groupBox18.Controls.Add(this.listBox3);
            this.groupBox18.Location = new System.Drawing.Point(77, 46);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(194, 167);
            this.groupBox18.TabIndex = 1007;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Immunizations";
            this.groupBox18.Visible = false;
            // 
            // textBox114
            // 
            this.textBox114.Location = new System.Drawing.Point(88, 113);
            this.textBox114.Name = "textBox114";
            this.textBox114.Size = new System.Drawing.Size(100, 20);
            this.textBox114.TabIndex = 7;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(54, 116);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(31, 13);
            this.label25.TabIndex = 6;
            this.label25.Text = "Text:";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(26, 137);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(138, 23);
            this.button5.TabIndex = 5;
            this.button5.Text = "Add Immunization";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBox115
            // 
            this.textBox115.Location = new System.Drawing.Point(88, 88);
            this.textBox115.Name = "textBox115";
            this.textBox115.Size = new System.Drawing.Size(100, 20);
            this.textBox115.TabIndex = 4;
            // 
            // textBox116
            // 
            this.textBox116.Location = new System.Drawing.Point(88, 65);
            this.textBox116.Name = "textBox116";
            this.textBox116.Size = new System.Drawing.Size(100, 20);
            this.textBox116.TabIndex = 3;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(50, 91);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(35, 13);
            this.label26.TabIndex = 2;
            this.label26.Text = "Code:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(10, 68);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(75, 13);
            this.label27.TabIndex = 1;
            this.label27.Text = "Display Name:";
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(3, 16);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(187, 43);
            this.listBox3.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 431);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox ListBoxPathType;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox TextBoxIntakeTabPatientLastNameIn;
        private System.Windows.Forms.TextBox TextBoxIntakeTabPatientFirstNameIn;
        private System.Windows.Forms.Label LabelIntakeTabLastName;
        private System.Windows.Forms.Label LabelIntakeTabFirstName;
        private System.Windows.Forms.Button ButtonIntakeTabBeginNewForm;
        private System.Windows.Forms.ComboBox GenderComboBox;
        private System.Windows.Forms.Label LabelIntakePatientGender;
        private System.Windows.Forms.TextBox TextBoxIntakeTabDOBYear;
        private System.Windows.Forms.Label LabelIntakeTabDOB;
        private System.Windows.Forms.ComboBox ComboBoxIntakeTabTribe;
        private System.Windows.Forms.Label LabelIntakeTabTribe;
        private System.Windows.Forms.Label LabelIntakeTabPresentVillage;
        private System.Windows.Forms.ComboBox ComboBoxIntakeTabPresentVillage;
        private System.Windows.Forms.ComboBox ComboBoxIntakeTabHomeVillage;
        private System.Windows.Forms.Label LabelIntakeTabeHomeVillage;
        private System.Windows.Forms.TextBox TextBoxIntakeTabEstAgeMonths;
        private System.Windows.Forms.TextBox TextBoxIntakeTabEstAgeYears;
        private System.Windows.Forms.TextBox TextBoxIntakeTabDOBMonth;
        private System.Windows.Forms.TextBox TextBoxIntakeTabStatedAgeYears;
        private System.Windows.Forms.TextBox TextBoxIntakeTabDOBDay;
        private System.Windows.Forms.TextBox TextBoxIntakeTabStatedAgeMonths;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LabelIntakeTabStatedAge;
        private System.Windows.Forms.Button ButtonIntakeTabAddLanguage;
        private System.Windows.Forms.ComboBox ComboBoxIntakeTabLanguageList;
        private System.Windows.Forms.Label LabelIntakeTabLanguage;
        private System.Windows.Forms.Label LabelIntakeTabSchoolYear;
        private System.Windows.Forms.ComboBox ComboBoxIntakeTabSchoolList;
        private System.Windows.Forms.Label LabelIntakeTabSchoolName;
        private System.Windows.Forms.Button ButtonIntakeTabWritePatientFile;
        private System.Windows.Forms.Label LabelIntakeTabSchoolStatus;
        private System.Windows.Forms.ComboBox ComboBoxIntakeTabStatusInSchool;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.ComboBox comboBox28;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Button IntakeTabReloadPatientButton;
        private System.Windows.Forms.Button ClinicTabLoadPatient;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button IntakeTabResetLanguageButton;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.ComboBox comboBoxScribeList;
        private System.Windows.Forms.Button ButtonSelectAgeType;
        private System.Windows.Forms.RichTextBox ClinicTabNotesEntry;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox TriageTabChiefComplaintInput;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Button TriageTabToggle;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox comboBox22;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.ComboBox comboBox23;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Button ButtonClinicSaveData;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.ComboBox comboBox27;
        private System.Windows.Forms.ComboBox comboBox26;
        private System.Windows.Forms.ComboBox comboBox25;
        private System.Windows.Forms.ComboBox comboBox24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.ComboBox comboBox29;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.TextBox textBox108;
        private System.Windows.Forms.TextBox textBox107;
        private System.Windows.Forms.TextBox textBox106;
        private System.Windows.Forms.TextBox textBox105;
        private System.Windows.Forms.TextBox textBox104;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.TextBox textBox99;
        private System.Windows.Forms.TextBox textBox98;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox110;
        private System.Windows.Forms.TextBox textBox109;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox113;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox111;
        private System.Windows.Forms.TextBox textBox112;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox textBox114;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox115;
        private System.Windows.Forms.TextBox textBox116;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ListBox listBox3;
    }
}

